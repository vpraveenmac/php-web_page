<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once(dirname(__DIR__) . '/Models/LoginModel.php');
include_once(dirname(__DIR__) . '/Models/UserModel.php');
include_once(dirname(__DIR__) . '/includes/emailer.php');
//include_once(dirname(__DIR__) . '/includes/brevo_emailer.php'); 

class LoginController
{
 private $loginModel;
 private $userModel;
public function __construct(){
        $this->loginModel = new LoginModel();
        $this->userModel = new UserModel();
    }

    public function Login()
    {
        //Kill Previous Session
        session_start();
        session_unset();
        session_destroy();

        
        //check if this is a post Method

        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:../login?error=Invalid call. HTTP POST Required");
            exit();

        }

        
        $login = htmlspecialchars($_POST['login']);
        $password = htmlspecialchars($_POST['password']); 
        $org = htmlspecialchars($_POST['org']); 

        $redirecturl = htmlspecialchars($_POST['redirect_url']); 

        $url = '/Views/login?login='. $login.'&org='.$org;

        if(empty($login)||empty($password)){
            //Login or password provided
            header("location:".$url . "&error=Required inputs were not provided");
            exit();
        }
       
        //Get User Detail
        $userDetail = $this->userModel->GetUserDetailByNameOrg($login,$org);
       
        if(count($userDetail) == 0)
        {
            //User or Email not found
            header("location:".$url . "&error=Username not found in the Organisation");
            exit();
        }
        //Check that the user is active
        if($userDetail[0]['active'] != 'Y')
        {
            //User or Email not found
            header("location:".$url . "&error=User is not active. Contact the Administrator");
            exit();
        }

        $storedPassword = $userDetail[0]['password'];
         //Check that the password has been set
         if(is_null($storedPassword)||empty($storedPassword))
         {
             //User or Email not found
             header("location:".$url . "&error=Password has not been set. Please use the 'Forget Password' link to set your password");
             exit();
         }
        if(!password_verify($password,$storedPassword)){
            //Password did not match
            header("location:".$url . "&error=Incorrect password");
            exit();

        }
        try
        {
            //Start Session if not started
            if (session_status() == PHP_SESSION_ACTIVE) {
            }
            else
            {
                session_start();
            }
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
            $_SESSION["UserName"] = $userDetail[0]['username'];
            $_SESSION["OrgName"] = $userDetail[0]['org_name'];
            
            //Set Access Level to OrgUser if empty
            if($userDetail[0]['accesslevel']=='' or empty($userDetail[0]['accesslevel']))
            {
                $_SESSION["AccessLevel"] = 'OrgUser';

            }
            else
            {
                $_SESSION["AccessLevel"] = $userDetail[0]['accesslevel'];

            }
        

         //If we are here the the login was successful. Call the included file to generate the session ID
       

            //Set Login Timestamp
            $currentDateTime = gmdate("Y-m-d H:i:s");
            $this->userModel->setLoginTS($currentDateTime,$login);
            //Get the redirection URL from session variable
            if($redirecturl != '')
            {
                echo "<script>parent.self.location='".$redirecturl."';</script>";
            }
            else
            {
                echo "<script>parent.self.location='/Views/SalesList';</script>";
            }
        }
        catch(Exception $e){
            $errormessage = 'Exception: ' .  $e->getMessage();
             header("location:".$url."&error=". $errormessage);
             exit();
        }



    }
    public function SendResetLink()
    {
        //check if this is a post Method
        

        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:../forgotpassword?error=Invalid call. HTTP POST Required");
            exit();

        }
        $login = htmlspecialchars($_POST['login']);
        $url = '/Views/forgotpassword?login='. $login;
        if(empty($login)){
            //Login or password provided
            header("location:".$url."&error=Required inputs were not provided");
            exit();
        }
       
        //Get User Detail
        $userDetail = $this->userModel->GetUserByName($login);
       //Check user exists
        if(count($userDetail) == 0)
        {
            // Email not found
            header("location:".$url."&error=Username not found");
            exit();
        }
        if($userDetail[0]['active'] != 'Y')
        {
            //User or Email not found
            header("location:".$url."&error=User is not active. Contact the Administrator");
            exit();
        }
        $userEmail = $userDetail[0]['email'];
        //Check that an email exists for the user
        
        if(empty($userEmail))
        {
            header("location:".$url."&error=No Email associated with the user. Contact Administrator");
            exit();
        }
            //Check that the email is valid
        if (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        header("location:".$url."&error=Email associated with the user: " . $userEmail . " is not valid. Contact Administrator");
        exit();
        }

        /*********** Generate the Token and Selector for the password reset functionality */

        //Will be used to query the user from the database
        $selector = bin2hex(random_bytes(8));
        //Will be used for confirmation once the database entry has been matched
        $token = random_bytes(32);
        //URL will vary depending on where the website is being hosted from
        $protocol='';
        if(isset($_SERVER['HTTPS'])){
            $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
        }
        else{
            $protocol = 'http';
        }
        $currentHostURL = $protocol . "://" . $_SERVER['SERVER_NAME'];
        $currentURLPort = $_SERVER['SERVER_PORT'];
        if($currentURLPort !='')$currentHostURL = $currentHostURL.':'.$currentURLPort;//Add port if it is present

        $passwordreseturl = $currentHostURL. '/Views/passwordreset?selector='.$selector.'&validator='.bin2hex($token);
        //Expiration date will last for half an hour
        $expires = date("U") + 1800;
        //Generate hashed Token
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        
        //Delete any existing tokens for the userId or email
        $this->loginModel->deleteResetToken($login,$login);
        //Insert the Reset Token into the database
        $result = $this->loginModel->insertResetToken($login,$selector, $hashedToken, $expires);

        if($result == 0){
            header("location:".$url."error=Something went wrong during token insertion");
            exit();
        }
        
         //If we are here then we can compose the Email
         $subject = "Online Sales Manager Password Reset";
         $message = "<br/><br/>We recieved a password reset request.";
         $message .= "<br/><br/>Here is your password reset link: ";
         $message .= "<a href='".$passwordreseturl."'>".$passwordreseturl."</a>";
         $message .= "<br/><br/>If you did not initiate this request then you can ignore this email and raise it as a concern with the web team.";
         $message .= "<br/><br/>Do not reply to this email";
 
         $tolist = array();
         array_push($tolist,$userEmail);

         //Setup Mailer
         $emailer = new Emailer('no-reply@onlinesalesmanager.com.au','Online Sales Manager Webmaster',$subject,$message,$tolist,null,null);

         try
         {
            //Send the email
            $responseCode = $emailer->SendEmail();
           //if(strlen($responseCode) == 3 && str_starts_with($responseCode,'2') ){
            /* We got a response code starting wth 2 like
            200="OK" , 201="Created" , 202="Accepted" , 203="Non-Authoritative Information", 204="No Content" ,205="Reset Content" ,206="Partial Content"
            */
            if(strtoupper($responseCode) == 'SUCCESS'){
            header("location:".$url."&success=An email with a reset link has been sent to " . $userEmail.'. Remember to check your Junk/Spam folders');
            exit();
                
            }
            else{
                throw new Exception("Something went wrong. Email Response Code::". $responseCode);
                exit();
            }
         }
         catch(Exception $e)
         {
             $errormessage = 'Exception: ' .  $e->getMessage();
             header("location:".$url."&error=". $errormessage);
             exit();
         }


    }

    public function ResetPassword()
    {
        $data = [
            'selector' => trim($_POST['selector']),
            'validator' => trim($_POST['validator']),
            'password' => trim($_POST['password']),
            'password2' => trim($_POST['password2'])
        ];

        $url = '/Views/passwordreset?selector='.$data['selector'].'&validator='.$data['validator'];
        $url2 = '/Views/forgotpassword';
        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:" . $url . "&error=Invalid call. HTTP POST Required");
            exit();

        }


        $password = htmlspecialchars($data['password']);
        $password2 = htmlspecialchars($data['password2']); 
        $selector = $data['selector'];
        $validator = $data['validator'];

        //check for empty values
        if(empty($password)){
            header("location:" . $url . "&error=Empty Password supplied");
            exit();
        }
        
        //Check passwords are the same
        if($password !== $password2)
        {
            header("location:" . $url . "&error=Passwords do not match");
            exit();
        }

        // Validate password strength
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);

        if(!$uppercase || !$lowercase || !$number || strlen($password) < 8) {
            header("location:" . $url . "&error=Password complexity rules not followed. See rules below");
            exit();
        }
        //Get the Reset Token Data using the selector
        $tokenDetail = $this->loginModel->getResetToken($selector);
        if(count($tokenDetail) == 0)
        {
            //Token Not found
            header("location:" . $url . "&error=Invalid Token");
            
            exit();
        }

        $currentDate = date("U");//Get Current Date Time
        if($currentDate > $tokenDetail[0]['expires']){
            header("location:" . $url2."?error=Link is no longer valid. Please obtain a new reset link");
            exit();
        }
        
        $passwordResetTokenDB = $tokenDetail[0]['hashedvalidator'];
        $tokenBin = hex2bin($validator);//Convert back to Binary
        $tokenCheck = password_verify($tokenBin, $passwordResetTokenDB);
        if(!$tokenCheck){
            header("location:".$url2."?error=Token validation error. Please obtain a new reset link: Password Reset Token DB: ".$passwordResetTokenDB);
            exit();
        }

        $tokenUsername = $tokenDetail[0]['username'];
        //Get the user record using the username
        $userDetail = $this->userModel->GetUserByName($tokenUsername);
        if(count($tokenDetail) == 0)
        {
            //Token does not belong to the email on record
            header("location:".$url2."?error=Sorry.Token is not valid for the email. Please obtain a new reset link");
            exit();
        }
        //If we are here then all checks have passed. Set the password on the record
        $newPwdHash = password_hash($password, PASSWORD_DEFAULT);
        $userName = $userDetail[0]['username'];
        $currentDateTime = gmdate("Y-m-d H:i:s");
        $rowCount  = $this->userModel->setPassword($newPwdHash,$userName,$currentDateTime,'Password Reset');
        if($rowCount == 0){
            header("location:" . $url . "&error=Something went wrong while setting the password" . $rowCount);
            exit();
        }
        //Now we can delete the token
        $this->loginModel->deleteResetToken($userName);
        //we will redirect them to the login page now
        header("location:/Views/login?success=Password successfully set. Please use it for login");



    }

    public function UpdatePassword()
    {
        //Set session variable to indicate we are going to make the Survey Tab active in the View
     
        $data = [
            'username' => trim($_POST['username']),
            'currentpassword' => trim($_POST['currentpassword']),
            'newpassword' => trim($_POST['newpassword']),
            'newpassword2' => trim($_POST['newpassword2'])
        ];

        $url = '/Views/updatepassword';
       

        try
        {
             //check if this is a post Method
            if ($_SERVER["REQUEST_METHOD"] != "POST") { 
                throw new Exception("Invalid call. HTTP POST Required");
            }
            
            $newpassword = htmlspecialchars($data['newpassword']);
            $newpassword2 = htmlspecialchars($data['newpassword2']); 
            $username = $data['username'];
            $currentpassword = $data['currentpassword'];

            //check for empty values
            if(empty($newpassword)){
                throw new Exception("Empty Password supplied");
            }
            
            //Check passwords are the same
            if($newpassword !== $newpassword2)
            {
                throw new Exception("Passwords do not match");
            }

            // Validate password strength
            $uppercase = preg_match('@[A-Z]@', $newpassword);
            $lowercase = preg_match('@[a-z]@', $newpassword);
            $number    = preg_match('@[0-9]@', $newpassword);

            if(!$uppercase || !$lowercase || !$number || strlen($newpassword) < 8) {
                throw new Exception("Password complexity rules not met. See rules");
            }
            //Get the Current Record using the Username
            $existingUser = $this->userModel->GetUserByName($username);
            if(count($existingUser) == 0)
            {
                //User not found
                throw new Exception("User not found");
            }
            $currentHashedPassword = $existingUser[0]['password'];

            
            $oldPasswordCheck = password_verify($currentpassword, $currentHashedPassword);
            if(!$oldPasswordCheck){
                throw new Exception("Old password is incorrect");
            }

            
            if($currentpassword == $newpassword){
                throw new Exception("Old password is same as the new password");
            }

            
            $currentDateTime = gmdate("Y-m-d H:i:s");

            //If we are here then all checks have passed. Set the password on the record
            $newPwdHash = password_hash($newpassword, PASSWORD_DEFAULT);//New Password Hash
            $rowCount  = $this->userModel->setPassword($newPwdHash,$username,$currentDateTime,$username);
            if($rowCount == 0){
                throw new Exception("Something went wrong while setting the password");
            }
            //Now we insert the Log
            //we will redirect them
            header("location:" . $url . "?success=Password successfully updated. Please use it for login next time onwards.#messageanchor");
        }
        catch(Exception $e)
        {
            //Use session variable to pass message back
            header("location:".$url."?error=".$e->getMessage()."#messageanchor");
        }

    }
    
    public function Logout()
    {
        session_start();
        session_unset();
        session_destroy();
        //go back to home page
        header("location:/index");
    }
}
$init = new LoginController();

//Ensure that user is sending a post request. We will read the action in the post to decide which method to invoke
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
        case 'Login':
            $init->Login();
            break;
            case 'SendResetLink':
                $init->SendResetLink();
                break;
            case 'ResetPassword':
                $init->ResetPassword();
                break;
            case 'UpdatePassword':
                $init->UpdatePassword();
                break;
            
        default:
        header("location:../login?error=Unknown action " . $action ." passed to Controller");
            exit();
    }
}
else if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $action = $_GET['action'];
    switch($action){
            case 'Logout':
                $init->Logout();
                break;
        default:
        header("location:../login?error=Unknown action " . $action ." passed to Controller");
            exit();
    }
}