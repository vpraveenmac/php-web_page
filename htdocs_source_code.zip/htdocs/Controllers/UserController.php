<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once(dirname(__DIR__) . '/Models/UserModel.php');
//include_once(dirname(__DIR__) . '/Models/UserOrgModel.php');

class UserController
{
 private $userModel;
public function __construct(){
        $this->userModel = new UserModel();
    }

    /********** UPSERT User FUNCTION ******************/
    public function UpsertUser()
    {
        $data = [
            'id' => trim($_POST['id']),
            'username' => trim($_POST['username']),
            'active' => trim($_POST['active']),
            'fullname' => trim($_POST['fullname']),
            'email' => trim($_POST['email']),
            'accesslevel' => trim($_POST['accesslevel']),
            'orgname' => trim($_POST['orgname'])
        ];
        $url = "/Views/UserList";

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:/index.php?error=Invalid call. HTTP POST Required");
            exit();

        }
       
        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;

        /********************** VALIDATIONS **********************/
        
         //Check that the username is provided 
         if(empty($data['username'])||empty($data['active'])||empty($data['fullname'])||empty($data['email'])||empty($data['accesslevel']))
         {
                $_SESSION['error'] = "one/more required values not provided";
                header("location:".$url."#messageanchor");
                exit();
         }

        try{
            
            $existingData = array();
            //first we get the existing data if the Id is not zero
            if($data['id'] != 0)
            {
                $existingData = $this->userModel->GetUserDetailById($data['id']);
            }
            if(count($existingData) == 0){
                //This is an insert scenario
                $newUser = new UserModelDB();
                $newUser->username = $data['username'];
                $newUser->active=$data['active'];
                $newUser->fullname=$data['fullname'];
                $newUser->email=$data['email'];
                $newUser->updatedby = $dataUpdator;
                $newUser->updated = $currentDateTime;
                $newUser->password = '';

                $result = $this->userModel->AddUser($newUser);
                if($result > 0)
                {
                    //Now we can add the organisation information
                    $userOrg = new UserOrgModelDB();
                    $userOrg->username=$data['username'];
                    $userOrg->orgname=$data['orgname'];
                    $userOrg->accesslevel=$data['accesslevel'];
                    $userOrg->active='Y';
                    $userOrg->updatedby = $dataUpdator;
                    $userOrg->updated = $currentDateTime;
                    $result1 = $this->userModel->AddUserOrg($userOrg);
                    if($result1 > 0)
                    {
                        header("location:".$url."?success=User added successfully#messageanchor");
                        exit();
                    }
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while adding data");
                }
            }
            else
            {
                //Update Scenario 
                $updateUser = new UserModelDB();
                $updateUser->username = $data['username'];
                $updateUser->active=$data['active'];
                $updateUser->fullname=$data['fullname'];
                $updateUser->email=$data['email'];
                $updateUser->updatedby = $dataUpdator;
                $updateUser->updated = $currentDateTime;
                $updateUser->id = $existingData[0]['id'];
                $result = $this->userModel->UpdateUser($updateUser);
                if($result > 0)
                {
                    //Now we can add the organisation information
                    $userOrg = new UserOrgModelDB();
                    $userOrg->username=$data['username'];
                    $userOrg->orgname=$data['orgname'];
                    $userOrg->accesslevel=$data['accesslevel'];
                    $userOrg->active='Y';
                    $userOrg->updatedby = $dataUpdator;
                    $userOrg->updated = $currentDateTime;
                    $check1 = $this->userModel->CheckUserOrg($data['username'],$data['orgname']);
                    $result1 = 0;
                    if(count($check1) == 0)
                    {
                        $result1 = $this->userModel->AddUserOrg($userOrg);
                    }
                    else
                    {
                        $result1 = $this->userModel->UpdateUserOrg($userOrg);
                    }
                    if($result1 > 0 )
                    {
                        header("location:".$url."?success=User updated successfully#messageanchor");
                        exit();
                    }
                    

                    header("location:".$url."?success=User updated successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while updating data");
                }
            }
        } 
        catch(Exception $e)
        {
            //Use session variable to pass message back
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
            exit();
        }
        
    }

    /********** DELETE USer FUNCTION ******************/
    public function DeleteUser()
    {
        $data = [
            'id' => trim($_POST['id']),
        ];
        $url = "/Views/UserList";

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:/index.php?error=Invalid call. HTTP POST Required");
            exit();

        }
       
        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;

        /********************** VALIDATIONS **********************/
        
         //Check that the id is provided 
         if(empty($data['id']))
         {
                $_SESSION['error'] = "User Id not provided";
                header("location:".$url."#messageanchor");
                exit();
         }
        try{
            //Get existing record
            $existingData = $this->userModel->GetUserDetailById($data['id']);
            
            if(count($existingData) == 0){
                //Org does not exist
                throw new Exception("USer with id:" . $data['id']. " does not exist");
            }
            else
            {
               
                $result = $this->userModel->DeleteUserById($data['id']);
                if($result > 0)
                {
                    header("location:".$url."?success=User deleted successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while deleting data");
                }
            }
        } 
        catch(Exception $e)
        {
            //Use session variable to pass message back
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
            exit();
        }
        
    }

    /********** DELETE USer Org FUNCTION ******************/
    public function DeleteUserOrg()
    {
        $data = [
            'delete_username' => trim($_POST['delete_username']),
            'delete_orgname' => trim($_POST['delete_orgname']),
        ];
        $url = "/Views/UserList";

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:/index.php?error=Invalid call. HTTP POST Required");
            exit();

        }
       
        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;

        /********************** VALIDATIONS **********************/
        
         //Check that the delete_orgname is provided 
         if(empty($data['delete_orgname']))
         {
                $_SESSION['error'] = "Org Name not provided";
                header("location:".$url."#messageanchor");
                exit();
         }
         if(empty($data['delete_username']))
         {
                $_SESSION['error'] = "User Name not provided";
                header("location:".$url."#messageanchor");
                exit();
         }
        try{
            //Get existing record
            $existingData = $this->userModel->CheckUserOrg($data['delete_username'],$data['delete_orgname']);
            
            if(count($existingData) == 0){
                //Org does not exist
                throw new Exception("User is not associated with the organisation");
            }
            else
            {
               
                $result = $this->userModel->DeleteUserOrg($data['delete_username'],$data['delete_orgname']);
                if($result > 0)
                {
                    header("location:".$url."?success=User removed from Organisation successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while deleting data");
                }
            }
        } 
        catch(Exception $e)
        {
            //Use session variable to pass message back
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
            exit();
        }
        
    }

  
}
$init = new UserController();

//Ensure that user is sending a post request. We will read the action in the post to decide which method to invoke
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
            case 'UpsertUser':
                $init->UpsertUser();
                break;
            case 'DeleteUser':
                $init->DeleteUser();
                break;
            case 'DeleteUserOrg':
                $init->DeleteUserOrg();
                break;
                
        default:
        $_SESSION['error']='Unknown action ' . $action .' passed to Controller';
        header("location:/Views/UserList#messageanchor");
        exit();
    }
}
