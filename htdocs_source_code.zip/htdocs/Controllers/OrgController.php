<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once(dirname(__DIR__) . '/Models/OrgModel.php');

class OrgController
{
 private $orgModel;
        
public function __construct(){
        $this->orgModel = new OrgModel();
    }

    /********** UPSERT ORG FUNCTION ******************/
    public function UpsertOrg()
    {
        $data = [
            'id' => trim($_POST['id']),
            'org_name' => trim($_POST['org_name']),
            'active' => trim($_POST['active'])
        ];
        $url = "/Views/OrgList";

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:/index.php?error=Invalid call. HTTP POST Required");
            exit();

        }
       
        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;

        /********************** VALIDATIONS **********************/
        
         //Check that the org_name is provided 
         if(empty($data['org_name']))
         {
                $_SESSION['error'] = "Org Name not provided";
                header("location:".$url."#messageanchor");
                exit();
         }
         //Check that the active is provided 
         if(empty($data['active']))
         {
                $_SESSION['error'] = "'active' value not provided";
                header("location:".$url."#messageanchor");
                exit();
         }

        try{
            
            $existingData = array();
            //first we get the existing data if the Id is not zero
            if($data['id'] != 0)
            {
                $existingData = $this->orgModel->GetOrgDetailById($data['id']);
            }
            if(count($existingData) == 0){
                //This is an insert scenario
                $newOrg = new OrgDetailModel();
                $newOrg->orgName = $data['org_name'];
                $newOrg->active=$data['active'];
                $newOrg->updatedBy = $dataUpdator;
                $newOrg->updated = $currentDateTime;

                $result = $this->orgModel->AddOrg($newOrg);
                if($result > 0)
                {
                    header("location:".$url."?success=Organisation added successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while adding data");
                }
            }
            else
            {
                //Update Scenario 
                $updateOrg = new OrgDetailModel();
                $updateOrg->orgName = $data['org_name'];
                $updateOrg->active=$data['active'];
                $updateOrg->updatedBy = $dataUpdator;
                $updateOrg->updated = $currentDateTime;
                $updateOrg->id = $existingData[0]['id'];
                $result = $this->orgModel->UpdateOrg($updateOrg);
                if($result > 0)
                {
                    header("location:".$url."?success=Organisation updated successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while updating data");
                }
            }
        } 
        catch(Exception $e)
        {
            //Use session variable to pass message back
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
            exit();
        }
        
    }

    /********** DELETE ORG FUNCTION ******************/
    public function DeleteOrg()
    {
        $data = [
            'org_name' => trim($_POST['org_name']),
        ];
        $url = "/Views/OrgList";

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:/index.php?error=Invalid call. HTTP POST Required");
            exit();

        }
       
        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;

        /********************** VALIDATIONS **********************/
        
         //Check that the org_name is provided 
         if(empty($data['org_name']))
         {
                $_SESSION['error'] = "Org Name not provided";
                header("location:".$url."#messageanchor");
                exit();
         }
        try{
            //Get existing record
            $existingData = $this->orgModel->GetOrgDetailByName($data['org_name']);
            
            if(count($existingData) == 0){
                //Org does not exist
                throw new Exception("Org with name:" . $data['org_name']. " does not exist");
            }
            else
            {
               
                $result = $this->orgModel->DeleteOrg($data['org_name']);
                if($result > 0)
                {
                    header("location:".$url."?success=Organisation deleted successfully#messageanchor");
                    exit();
                }
                else
                {
                    //Use session variable to pass message back
                    throw new Exception("Something went wrong while deleting data");
                }
            }
        } 
        catch(Exception $e)
        {
            //Use session variable to pass message back
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
            exit();
        }
        
    }

     
  
}
$init = new OrgController();

//Ensure that user is sending a post request. We will read the action in the post to decide which method to invoke
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
            case 'UpsertOrg':
                $init->UpsertOrg();
                break;
            case 'DeleteOrg':
                $init->DeleteOrg();
                break;
        default:
        $_SESSION['error']='Unknown action ' . $action .' passed to Controller';
        header("location:/Views/OrgList#messageanchor");
        exit();
    }
}
