<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
//error_reporting(E_ALL^ E_WARNING);
error_reporting(E_ALL);

include_once(dirname(__DIR__) . '/Models/CarSalesModel.php');
include_once(dirname(__DIR__) . '/Models/CarSalesExpenseModel.php');
include_once(dirname(__DIR__) . '/Models/CarSalesLogModel.php');
include_once(dirname(__DIR__) . '/Models/CarSalesNoteModel.php');
include_once(dirname(__DIR__) . '/includes/PhpXlsxGenerator.php');
include_once(dirname(__DIR__) . '/includes/emailer.php');
include_once(dirname(__DIR__) . '/Models/UserModel.php');

class CarSalesController
{
    private $carsalesModel;
    private $carsalesExpenseModel;
    private $carsalesLogModel;
    private $carsalesNoteModel;
    public function __construct() {
        $this->carsalesModel = new CarSalesModel();
        $this->carsalesExpenseModel = new CarSalesExpenseModel();
        $this->carsalesLogModel = new CarSalesLogModel();
        $this->carsalesNoteModel = new CarSalesNoteModel();
    }



  
    /********** Export Data FUNCTION ******************/
    public function ExportData()
    {

        $url = '/Views/SalesList';
        //Check that the user is logged in
        if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
        {
            header("location:/Views/login?error=Please login to complete action#messageanchor");
            exit();
        }

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            $_SESSION['error'] = 'nvalid call. HTTP POST Required';
            header("location:" . $url . "#messageanchor");
            exit();

        }
        

        //Check that the referee is logged in
        if(!isset($_POST["ExportHeader"])|| !isset($_POST["ExportContent"]))
        {
            $_SESSION['error'] = 'ExportHeader and ExportContent not passed in';
            header("location:" . $url . "#messageanchor");
            exit();
        }
 
        try{
            //Get the posted values
            $ExportHeader = $_POST['ExportHeader'];
            $ExportContent = $_POST['ExportContent'];
          
             // Set PHP headers for plaintext output.
             $filename="sales_export_".date("Y-m-d H:i:s").".xlsx";
         
             $excelData = array();

            // Create the headers.
            $header = explode('|',$ExportHeader);
            $excelData[] = $header;

            //Create the Contents
            $contentList = explode('[CRLF]',$ExportContent);
            
            // Loop through the prepared data to output it to file.
            $count = 0;
            foreach( $contentList as $record ){
                //Explode each line by the delimiter
                $count++;
                $contentArray = explode('|',$record);
                $excelData[] = $contentArray;
            }
            
            // Export data to excel and download as xlsx file 
            $xlsx = CodexWorld\PhpXlsxGenerator::fromArray( $excelData ); 
            $xlsx->downloadAs($filename); 
 
            exit(); 

        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }   
        
    }

    /********** Upsert Data FUNCTION ******************/
    public function UpsertData()
    {

        $url = '/Views/EditCarSale';
         //Check that the user is logged in
         if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
         {
             header("location:/Views/login?error=Please login to complete action#messageanchor");
             exit();
         }

         $dataUpdator = $_SESSION["UserName"];
         $orgName=$_SESSION['OrgName'];//OrgName is set from the session variable

 
        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            $_SESSION['error'] = 'Invalid call. HTTP POST Required';
            header("location:/Views/SalesList#messageanchor");
            exit();

        }
        
        try{
            $currentDateTime = gmdate("Y-m-d H:i:s");
            //Build the DB Model using the posted values
            $salesDBModel = new CarSalesModelDB();
            if(!isset($_POST['sales_no']))
            {
                throw new Exception("Sales No was not passed in");
            }
            if(trim($_POST['sales_no'])=='')
            {
                throw new Exception("Empty Sales No was passed in");
            }
            if(isset($_POST['sales_no']))
            {
                $salesDBModel->sales_no=$_POST['sales_no'];//For create command it should be sent as 0
            }
            $url = '/Views/EditCarSale?SalesNo='.$_POST['sales_no'];//Set the Return URL

            if($_POST['sales_no'] == '0')//FOr new record we need to set the Created and Created By
            {
                $salesDBModel->created=$currentDateTime;//set default to now
                $salesDBModel->created_by=$dataUpdator;
            }

            $salesDBModel->updated=$currentDateTime;
            $salesDBModel->updated_by=$dataUpdator;
            if(isset($_POST['car_make']))
            {
                $salesDBModel->car_make=$_POST['car_make'];
            }
            if(isset($_POST['car_model']))
            {
                $salesDBModel->car_model=$_POST['car_model'];
            }
            if(isset($_POST['car_color']))
            {
                $salesDBModel->car_color=$_POST['car_color'];
            }
            if(isset($_POST['car_year']) && !empty($_POST['car_year']))
            {
                $salesDBModel->car_year=$_POST['car_year'];
            }
            if(isset($_POST['transmission']))
            {
                $salesDBModel->transmission=$_POST['transmission'];
            }
            if(isset($_POST['car_rego']))
            {
                $salesDBModel->car_rego=$_POST['car_rego'];
            }
            if(isset($_POST['rego_expiry']) && !empty($_POST['rego_expiry']))
            {
                $salesDBModel->rego_expiry=$_POST['rego_expiry'];
            }
            if(isset($_POST['mileage']) && !empty($_POST['mileage']))
            {
                $salesDBModel->mileage=$_POST['mileage'];
            }
            if(isset($_POST['specifications']))
            {
                $salesDBModel->specifications=$_POST['specifications'];
            }
            if(isset($_POST['ADED']) && !empty($_POST['ADED']))
            {
                $salesDBModel->ADED=$_POST['ADED'];
            }
            if(isset($_POST['purchase_date']) && !empty($_POST['purchase_date']))
            {
                $salesDBModel->purchase_date=$_POST['purchase_date'];
            }
            if(isset($_POST['purchase_price']) && !empty($_POST['purchase_price']))
            {
                $salesDBModel->purchase_price=$_POST['purchase_price'];
            }
            if(isset($_POST['sold_price']) && !empty($_POST['sold_price']))
            {
                $salesDBModel->sold_price=$_POST['sold_price'];
            }
            if(isset($_POST['sold_date'])&& !empty($_POST['sold_date']))
            {
                $salesDBModel->sold_date=$_POST['sold_date'];
            }
            
            if(isset($_POST['sale_status']))
            {
                $salesDBModel->sale_status=$_POST['sale_status'];
            }
            if(isset($_POST['damage']))
            {
                $salesDBModel->damage=$_POST['damage'];
            }
           
            if(isset($_POST['stock_location']))
            {
                $salesDBModel->stock_location=$_POST['stock_location'];
            }
            
            if(isset($_POST['date_advertised']) && !empty($_POST['date_advertised']))
            {
                $salesDBModel->date_advertised=$_POST['date_advertised'];
            }
            if(isset($_POST['transferred']))
            {
                $salesDBModel->transferred=$_POST['transferred'];
            }
            if(isset($_POST['sales_person']))
            {
                $salesDBModel->sales_person=$_POST['sales_person'];
            }
            
            if(isset($_POST['fuel_type']))
            {
                $salesDBModel->fuel_type=$_POST['fuel_type'];
            }
            if(isset($_POST['work_scheduled_date']) && !empty($_POST['work_scheduled_date']))
            {
                $salesDBModel->work_scheduled_date=$_POST['work_scheduled_date'];
            }
            if(isset($_POST['stock_owner']) && !empty($_POST['stock_owner']))
            {
                $salesDBModel->stock_owner=$_POST['stock_owner'];
            }

            $salesDBModel->org_name=$orgName;
            /***************************************************************************************************************************
            **  Now if we see an expense was entered, we will assign it to a variable to be used in Profile/Loss/Expense calculation **
            **************************************************************************************************************************** */
            $newExpenseValue = 0;//Variable to hold new expense value being added.
            if(isset($_POST['add_expense_type'])&&!empty($_POST['add_expense_type'])&&isset($_POST['add_expense_value'])&&!empty($_POST['add_expense_value']))
            {
                $newExpenseValue = $_POST['add_expense_value'];
            }

            
            /********************************************************************************************************************
            ********************* NEED CALCULATION of Profit, GST and Expense using the other pieces of information 
            Include the new expense that might be sent in as well. we will actually create the expense record later on **************
            ********************************************************************************************************************/
            $expenseList = $this->carsalesExpenseModel->GetSalesExpensesBySalesNoOrg($salesDBModel->sales_no,$orgName);//Get existing entries from the Expense Table
            $profitGSTExpense = $this->calculateProfitGSTAndExpense($salesDBModel->purchase_price,$salesDBModel->sold_price,$expenseList,$newExpenseValue);
            $salesDBModel->total_expenses=$profitGSTExpense->totalExpenses;
            $salesDBModel->gst=$profitGSTExpense->gst;
            $salesDBModel->profit=$profitGSTExpense->profit;
            /******************************************************************** *
             ***************** WORKITEM List computation  ************************
            The work items that were checked on the UI will be sent via POST parameters in an array named Worklist
            WorkItem[]: Detailing
            WorkItem[]: Painting
            WorkItem[]: Key Repairs
            /************************************************************************ */
            $workitemlist = '';//initialise
            foreach ($_POST['WorkItem'] as $inputworkitem) {
                $workitemlist = $workitemlist . $inputworkitem.'|';//Append it to our variable after trimming out the word 'WorkItem_'
            }
            $workitemlist = rtrim($workitemlist, '|');//remove the trailing pipe delimiter added for the last value inside the loop
            $salesDBModel->workitem_list = $workitemlist;//Assign value to the model
            $successMessage = '';//Variable to hold the success message
            $oldStockOwner = '';
            $newStockOwner = '';
            /****** if the Sales_No field is 0 or empty then we need to add the record, else we need to update it ******** */
            if(is_null($salesDBModel->sales_no) || empty($salesDBModel->sales_no) || ($salesDBModel->sales_no == 0) )
            {
               $logText = "Entry Created";
               $newSalesNo = $this->carsalesModel->AddCarSale($salesDBModel);
               $url = '/Views/EditCarSale?SalesNo='.$newSalesNo;//Update the return URL to take us to the sales detail of newly created record
               
               $salesDBModel->sales_no = $newSalesNo;//Update the Model with the newly created SalesNo
               $logDBModel = new CarSalesLogModelDB();
               $logDBModel->created = $currentDateTime;
               $logDBModel->created_by = $dataUpdator;
               $logDBModel->log = $logText;
               $logDBModel->org_name = $salesDBModel->org_name;//Get from the sales model
               $logDBModel->sales_no = $salesDBModel->sales_no;//get from the sales model

                $this->carsalesLogModel->AddLog($logDBModel);//Write the Log
                $successMessage = 'Record Created successfully';
            }
            else
            {
                $existingSalesData = $this->carsalesModel->GetSalesDetailBySalesNoOrg($salesDBModel->sales_no,$salesDBModel->org_name);
                if(count($existingSalesData)==0)
                {
                    throw new Exception("No Sales data found for Sales_No:".$salesDBModel->sales_no);
                }
                $url = '/Views/EditCarSale?SalesNo='.$salesDBModel->sales_no;//Update the return URL to take us to the sales detail
                //Get new and existing stock owners
                $oldStockOwner = $existingSalesData[0]['stock_owner'];
                $newStockOwner = $salesDBModel->stock_owner;
                //We shall first figure out the changes to write the logtext. 
                
                $logText = '';
                foreach ($salesDBModel as $key => $value) {
                    if (($key == "sales_no") || ($key== "created_by")||($key == "created")||($key == "updated")||($key == "updated_by")) continue;//No Need to record these
                    if($existingSalesData[0][$key] != $value)
                    {
                        //Value has changed to add it to the log
                        $logText = $logText . $key . ":'" . $existingSalesData[0][$key] . "' to '" . $value . "',";
                    }
              
                }
                
                //Remove last comma of the Log Text
                $logText = rtrim($logText,',');
                if($logText != '')
                {
                    //If we are here it means there was some change done so we need to save the record.
                    $salesDBModel->created=$existingSalesData[0]['created'];
                    $salesDBModel->created_by=$existingSalesData[0]['created_by'];
                    
                    
                    $updateCount = $this->carsalesModel->UpdateCarSale($salesDBModel);
                    if($updateCount == 0)
                    {
                        throw new Exception('Something went wrong in Updating the record');
                    }

                    $logDBModel = new CarSalesLogModelDB();
                    $logDBModel->created = $currentDateTime;
                    $logDBModel->created_by = $dataUpdator;
                    $logDBModel->log = $logText;
                    $logDBModel->org_name = $salesDBModel->org_name;//Get from the sales model
                    $logDBModel->sales_no = $salesDBModel->sales_no;//get from the sales model
                    $this->carsalesLogModel->AddLog($logDBModel);//Write the Log
                }
                $successMessage = 'Record Edited successfully';
            }


            /*************** Now if we see a note was passed we will add it ***************** */
            if(isset($_POST['add_note'])&&!empty($_POST['add_note']))
            {
                $noteModel = new CarSalesNoteModelDB();
                $noteModel->note = $_POST['add_note'];
                $noteModel->created = $currentDateTime;
                $noteModel->created_by=$dataUpdator;
                $noteModel->sales_no=$salesDBModel->sales_no;//Get from the car model
                $noteModel->org_name=$salesDBModel->org_name;//Get from the car model
                $this->carsalesNoteModel->AddNote($noteModel);//Write the Log
            }

             /*********************************************************************************************
            ******************  Now if we see an expense was entered, we will add the record ******************
            ******************************************************************************************** */
            $expenseAddLog = '';//Variable to hold the note if an expense was added
            if(isset($_POST['add_expense_type'])&&!empty($_POST['add_expense_type'])&&isset($_POST['add_expense_value'])&&!empty($_POST['add_expense_value']))
            {
                $expenseType = $_POST['add_expense_type'];//This should correspond to the name of the model property
                $expenseValue = $_POST['add_expense_value'];
                $expenseBy = $_POST['add_expense_by'];

                $addExpenseModel = new CarSalesExpenseModelDB();
                $addExpenseModel->created = $currentDateTime;
                $addExpenseModel->created_by = $dataUpdator;
                $addExpenseModel->expense_type = $expenseType;
                $addExpenseModel->expense_value = $expenseValue;
                $addExpenseModel->expense_by = $expenseBy;
                $addExpenseModel->org_name = $orgName;
                $addExpenseModel->sales_no = $salesDBModel->sales_no;//For newly created record we would have populated this earlier with the new salesNo

                $this->carsalesExpenseModel->AddExpense($addExpenseModel);
                //$previousExpenseValue = $salesDBModel->$expenseType;
                //$newExpenseValue = (is_null($previousExpenseValue)||empty($previousExpenseValue) ? 0 : $previousExpenseValue) + $expenseValue;
                //$salesDBModel->$expenseType = $newExpenseValue;//Update the model expense type with the new value so that it will be handled accordingly.

                $expenseAddLog = 'Added Expense Type:'.$expenseType. ' of $'.$expenseValue. ' by '. $expenseBy;
            }
  

            /*************** Now if we see an expense note was set ...we will add that additional log ***************** */
            if($expenseAddLog !='')
            {
                $logDBModel = new CarSalesLogModelDB();
                $logDBModel->created = $currentDateTime;
                $logDBModel->created_by = $dataUpdator;
                $logDBModel->log = $expenseAddLog;
                $logDBModel->org_name = $salesDBModel->org_name;//Get from the car model
                $logDBModel->sales_no = $salesDBModel->sales_no;//get from the sales model
 
                 $this->carsalesLogModel->AddLog($logDBModel);//Write the Log
            }

            //IF stock owner has changed then send them an email
            if($oldStockOwner !=''  && !empty($oldStockOwner))
            {
                if($oldStockOwner != $newStockOwner)
                {
                    //If we are here then we can compose the Email
                    $subject = "Stock Owner Changed for SalesNo : " . $salesDBModel->sales_no;
                    $message = "The Stock Owner has changed for the record below.";
                    $message .= "<br/>Sales No: ".$salesDBModel->sales_no;
                    $message .= "<br/>Organisation: ".$salesDBModel->org_name;
                    $message .= "<br/>Make: ".$salesDBModel->car_make;
                    $message .= "<br/>Model: ".$salesDBModel->car_model;
                    $message .= "<br/>Year: ".$salesDBModel->car_year;
                    $message .= "<br/>Rego: ".$salesDBModel->car_rego;
                    $message .= "<br/>Old Stock Owner: <b>".$oldStockOwner."</b>";
                    $message .= "<br/>New Stock Owner: <b>".$newStockOwner."</b>";
                    $message .= "<br/>Updated By: ".$salesDBModel->updated_by;
                    $updatedTS = new DateTime($salesDBModel->updated);
                    $updatedTS = $updatedTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                    $updatedTSSyd = $updatedTS->format('Y-m-d H:i:s'); // Change to Sydney
                    $message .= "<br/>Updated At: ".$updatedTSSyd;
                    //Get the old and new owner emails.
                    $tolist = array();//To Email list
                    $userModel = new UserModel();
                    //Get old owner
                    $userlist = $userModel->GetUserByName($oldStockOwner);
                    if(count($userlist) > 0)
                    {
                        array_push($tolist,$userlist[0]['email']);//add to email TO list if it exists
                    }
                    //Get new owner
                    $userlist = $userModel->GetUserByName($newStockOwner);
                    if(count($userlist) > 0)
                    {
                        array_push($tolist,$userlist[0]['email']);//add to email TO list if it exists
                    }
 
                    //Setup Mailer
                    $emailer = new Emailer('no-reply@onlinesalesmanager.com.au','Online Sales Manager Webmaster',$subject,$message,$tolist,null,null);
                    try
                    {
                        //Send the email
                        $responseCode = $emailer->SendEmail();
                         if(strlen($responseCode) == 3 && str_starts_with($responseCode,'2') )
                         {
                            /* We got a response code starting wth 2 like
                            200="OK" , 201="Created" , 202="Accepted" , 203="Non-Authoritative Information", 204="No Content" ,205="Reset Content" ,206="Partial Content"
                            */
                            if(strtoupper($responseCode) == 'SUCCESS'){
                                //email was sent successfully
                            }
                            else{
                                throw new Exception("Something went wrong sending Stock Owner change notification. Email Response Code::". $responseCode);
                            }
                        }
                    }
                    catch(Exception $e)
                    {
                        $errormessage = 'Exception during sending Stock Owner change notification email: ' .  $e->getMessage();
                        header("location:".$url."&error=". $errormessage);
                        exit();
                    }

                }
            }

           

            header("location:".$url."&success=".$successMessage."#messageanchor");
            exit();

        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }   
        
    }

    /********** Delete Data FUNCTION. We will set the status to Deleted ******************/
    public function DeleteData()
    {
        $url = '/Views/SalesList';
         //Check that the user is logged in
         if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
         {
             header("location:/Views/login?error=Please login to complete action#messageanchor");
             exit();
         }

         $dataUpdator = $_SESSION["UserName"];

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            $_SESSION['error'] = 'Invalid call. HTTP POST Required';
            header("location:/Views/SalesList#messageanchor");
            exit();
        }
        
         
		try{
            if(!isset($_POST['sales_no']))
            {
                throw new Exception('Sales No. was not passed in');
            }

            $currentDateTime = gmdate("Y-m-d H:i:s");
            $salesNo = $_POST['sales_no'];
            $orgName = $_SESSION['OrgName'];
            
			
             $existingSalesData = $this->carsalesModel->GetSalesDetailBySalesNoOrg($salesNo,$orgName);
            if(count($existingSalesData)==0)
            {
                throw new Exception("No Sales data found for Sales No:".$salesNo);
            }
            $url = '/Views/EditCarSale?SalesNo='.$salesNo;//Update the return URL to take us to the sales detail
               
            //If we are here it means there was some change done so we need to save the record.
            $updateCount = $this->carsalesModel->UpdateSalesStatusBySalesNoOrg($salesNo,$orgName,'Deleted',$currentDateTime,$dataUpdator);
            if($updateCount == 0)
            {
                throw new Exception('Something went wrong in Updating the record');
            }

            //Write the log

            $logDBModel = new CarSalesLogModelDB();
            $logDBModel->created = $currentDateTime;
            $logDBModel->created_by = $dataUpdator;
            $logDBModel->log = 'Record Deleted';
            $logDBModel->org_name = $orgName;
            $logDBModel->sales_no = $salesNo;
            $this->carsalesLogModel->AddLog($logDBModel);//Write the Log

		    header("location:".$url."&success=Record set to Deleted status#messageanchor");
            exit();

        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }   
    }


    private function calculateProfitGSTAndExpense($purchasePrice,$soldPrice,$expenseList,$newExpenseValue)
    {
        $totalCost = 0;//Initialise so that it is taken as a number
        $totalProfit = 0;
        $totalCost = $totalCost + (is_null($purchasePrice)||empty($purchasePrice) ? 0 : floatval($purchasePrice));//Purchase Price
        //Now we go thorugh th expense List and add it to the Total Cost
        foreach($expenseList as $expense){
            $totalCost = $totalCost + $expense['expense_value'];
        }
        //Add the new expense to the total. It will be passed in as Zero if there was none
        $totalCost = $totalCost + $newExpenseValue;
        
        $salePrice = 0;//Initialise so that it is taken as a number
        $salePrice = $salePrice + (is_null($soldPrice) ? 0 : floatval($soldPrice));
        $totalProfit = $salePrice - $totalCost;
        $gst = round($totalProfit / 11);
        $result = new ExpenseProfitGST();
        $result->totalExpenses = $totalCost;
        $result->profit = $totalProfit;
        $result->gst = $gst;
        return ($result);


    }

   /********** DeleteExpense Function ******************/
   public function DeleteExpense()
   {
       $url = '/Views/SalesList';
        //Check that the user is logged in
        if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
        {
            header("location:/Views/login?error=Please login to complete action#messageanchor");
            exit();
        }

        $dataUpdator = $_SESSION["UserName"];

       //check if this is a post Method
       if ($_SERVER["REQUEST_METHOD"] != "POST") { 
           $_SESSION['error'] = 'Invalid call. HTTP POST Required';
           header("location:/Views/SalesList#messageanchor");
           exit();
       }
       
        
       try{
           if(!isset($_POST['sales_no']))
           {
               throw new Exception('Sales No. was not passed in');
           }

           $currentDateTime = gmdate("Y-m-d H:i:s");
           $salesNo = $_POST['sales_no'];
           $orgName = $_SESSION['OrgName'];
           $salesNo = $_POST['sales_no'];
           //Now we have the sales no so we can modify the return URL
           $url = '/Views/EditCarSale?SalesNo='.$salesNo;
           //GEt existing sales Data
           $existingSalesData = $this->carsalesModel->GetSalesDetailBySalesNoOrg($salesNo,$orgName);
           if(count($existingSalesData)==0)
           {
            throw new Exception("Sales Data was not found for SalesNo:".$salesNo);
           }
           //Record old values and variables
           $oldExpense = $existingSalesData[0]['total_expenses'];
           $oldProfit = $existingSalesData[0]['profit'];
           $oldGST = $existingSalesData[0]['gst'];
           $purchasePrice = $existingSalesData[0]['purchase_price'];
           $soldPrice = $existingSalesData[0]['sold_price'];

           if(!isset($_POST['expense_id']))
            {
                throw new Exception('Expense Id was not passed in');
            }
            $expenseid = $_POST['expense_id'];
             //Check the expense exists
             $existingExpense = $this->carsalesExpenseModel->GetSalesExpensesByIdSalesNoOrg($expenseid,$salesNo,$orgName);
             if(count($existingExpense) == 0)
             {
                 throw new Exception('Expense record does not exist');
             }
             //Form the Log text
             $logText = 'Deleted::Expense Type: '.$existingExpense[0]['expense_type'].',Value: $'.$existingExpense[0]['expense_value'].',Expensed By:'. $existingExpense[0]['expense_by'].',Created:'.$existingExpense[0]['created'].',Created By:'.$existingExpense[0]['created_by'];
           //Try deleting the expense
           $rowCount = $this->carsalesExpenseModel->DeleteExpense($expenseid,$salesNo,$orgName);
           if($rowCount==0)
           {
               throw new Exception("Failed to delete the file");
           }

           //Get updated expense list
           $newExpenseList = $this->carsalesExpenseModel->GetSalesExpensesBySalesNoOrg($salesNo,$orgName);

           //Recalculate the Profit GST and Expense
           $expenseProfitGST = $this->calculateProfitGSTAndExpense($purchasePrice,$soldPrice,$newExpenseList,0);
           //Update the Expense Profit and GST
           $this->carsalesModel->UpdateExpenseProfitGST($salesNo,$orgName,$expenseProfitGST->totalExpenses,$expenseProfitGST->profit,$expenseProfitGST->gst,$currentDateTime,$dataUpdator);
           
           //Write the log for the expense delete
           $logDBModel = new CarSalesLogModelDB();
           $logDBModel->created = $currentDateTime;
           $logDBModel->created_by = $dataUpdator;
           $logDBModel->log = $logText;
           $logDBModel->org_name = $orgName;
           $logDBModel->sales_no = $salesNo;
           $this->carsalesLogModel->AddLog($logDBModel);//Write the Log
           //Write the log for the Expense,Profit, GST changes
           $logText = 'total_expenses: '.$oldExpense . ' to '. $expenseProfitGST->totalExpenses.' ,profit: '.$oldProfit . ' to '. $expenseProfitGST->profit.' ,gst: '.$oldGST . ' to '. $expenseProfitGST->gst;
           $logDBModel = new CarSalesLogModelDB();
           $logDBModel->created = $currentDateTime;
           $logDBModel->created_by = $dataUpdator;
           $logDBModel->log = $logText;
           $logDBModel->org_name = $orgName;
           $logDBModel->sales_no = $salesNo;
           $this->carsalesLogModel->AddLog($logDBModel);//Write the Log


           header("location:".$url."&success=Expense Deleted#messageanchor");
            exit();
       }
       catch(Exception $e)
       {
           $_SESSION['error'] = "Exception: " .  $e->getMessage();
           header("location:".$url."#messageanchor");
            exit();
       }   
   }


   
} 

$init = new CarSalesController();
/* We are going to server our View Requests which will all come via  GET method */
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $action = $_GET['action'];
    switch($action){
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}
else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
            case 'ExportData':
                $init->ExportData();
                break;
            case 'UpsertData':
                $init->UpsertData();
                break;
            case 'DeleteExpense':
                $init->DeleteExpense();
                break;
                
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}