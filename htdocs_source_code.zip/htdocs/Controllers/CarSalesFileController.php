<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
//error_reporting(E_ALL^ E_WARNING);
error_reporting(E_ALL);
include_once(dirname(__DIR__) . '/Models/CarSalesModel.php');
include_once(dirname(__DIR__) . '/Models/CarSalesFileModel.php');
include_once(dirname(__DIR__) . '/Models/CarSalesLogModel.php');

class CarSalesFileController
{
    private $carsalesModel;
    private $carsalesFileModel;
    private $carsalesLogModel;
    public function __construct() {
        $this->carsalesModel = new CarSalesModel();
        $this->carsalesFileModel = new CarSalesFileModel();
        $this->carsalesLogModel = new CarSalesLogModel();
    }


    /********** Add File FUNCTION ******************/
    public function UploadFile()
    {
        $url = '/Views/CarSaleFile';
        //Check that the user is logged in
        if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
        {
            header("location:/Views/login?error=Please login to complete action#messageanchor");
            exit();
        }

        $dataUpdator = $_SESSION["UserName"];
        $orgName = $_SESSION['OrgName'];//OrgName from session variable
       //check if this is a post Method
       if ($_SERVER["REQUEST_METHOD"] != "POST") { 
           $_SESSION['error'] = 'Invalid call. HTTP POST Required';
           header("location:/Views/SalesList#messageanchor");
           exit();
       }

       //Now get the sales No passed in
       if(!isset($_POST['sales_no']))
       {
            $_SESSION['error'] = 'Sales No. not passed in';
            header("location:/Views/SalesList#messageanchor");
            exit();
       }
       $salesNo = $_POST['sales_no'];
       //Check that the sale data exists
       $existingSalesData = $this->carsalesModel->GetSalesDetailBySalesNoOrg($salesNo,$orgName);
        if(count($existingSalesData)==0)
        {
            $_SESSION['error'] = "No Sales data found for Sales No:".$salesNo;
            header("location:/Views/SalesList#messageanchor");
            exit();
        }

       $url = '/Views/CarSaleFile?SalesNo='.$salesNo;//set the return URL as we have now confirmed the record

       
        
       //Check the file was loaded
        if(!isset($_FILES['formFile']) || $_FILES['formFile']['error'] != 0) {
            $_SESSION['error'] = "Upload File was not provided";
            header("location:".$url."#messageanchor");
            exit();
        }

        $currentDateTime = gmdate("Y-m-d H:i:s");

        /* If a file was posted then we will try to upload it */
        if(isset($_FILES['formFile']) && $_FILES['formFile']['error'] == 0) {
            $filename = $_FILES['formFile']['name'];
            // Notice how to grab MIME type.
            $mime_type = mime_content_type($_FILES['formFile']['tmp_name']);
            //check file size
            if($_FILES['formFile']['size'] > 5242880)
            {
                $_SESSION['error'] = "File is too big(> 5MB)";
                header("location:".$url."#messageanchor");
                exit();
            }

            if($_FILES['formFile']['size'] == 0)
            {
                $_SESSION['error'] = "Zero byte File passed in";
                header("location:".$url."#messageanchor");
                exit();
            }
            //Read the file contents
            $file_content = file_get_contents($_FILES['formFile']['tmp_name']);
            //create the DB model
            $fileDBModel = new CarSalesFileModelDB();
            $fileDBModel->sales_no = $salesNo;
            $fileDBModel->created = $currentDateTime;
            $fileDBModel->created_by = $dataUpdator;
            $fileDBModel->description = $filename;
            $fileDBModel->mime_type = $mime_type;
            $fileDBModel->data = $file_content;
            $fileDBModel->org_name = $orgName;
            try{
                $result = $this->carsalesFileModel->AddFile($fileDBModel);
                if($result == 0){
                    throw new Exception("Failed to insert data");
                }
                header("location:".$url."&success=File Uploaded successfully#messageanchor");
            }
            catch(Exception $ex)
            {
                $_SESSION['error'] = "Error while uploading file: ". $ex->getMessage();
                header("location:".$url."#messageanchor");
                exit();
            }
        }

    }

    /********** Delete File FUNCTION ******************/
    public function DeleteFile()
    {
        $url = '/Views/SalesList';
         //Check that the user is logged in
         if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
         {
             header("location:/Views/login?error=Please login to complete action#messageanchor");
             exit();
         }

         $dataUpdator = $_SESSION["UserName"];

        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            $_SESSION['error'] = 'Invalid call. HTTP POST Required';
            header("location:/Views/SalesList#messageanchor");
            exit();
        }
        
         
		try{
            if(!isset($_POST['sales_no']))
            {
                throw new Exception('Sales No. was not passed in');
            }
            $salesNo = $_POST['sales_no'];
            //Now we have the sales no so we can modify the return URL
            $url = '/Views/CarSaleFile?SalesNo='.$salesNo;
            $orgName = $_SESSION['OrgName'];
            if(!isset($_POST['file_id']))
            {
                throw new Exception('File Id waswas not passed in');
            }
            $fileId = $_POST['file_id'];
            $currentDateTime = gmdate("Y-m-d H:i:s");
            //Check the file exists
            $existingFile = $this->carsalesFileModel->GetFile($fileId,$salesNo,$orgName);
            if(count($existingFile) == 0)
            {
                throw new Exception('File record does not exist');
            }
            $fileDescription = $existingFile[0]['description'];//Will be useful for logging later on
            //Try deleting the file
            $rowCount = $this->carsalesFileModel->DeleteFile($fileId,$salesNo,$orgName);
            if($rowCount==0)
            {
                throw new Exception("Failed to delete the file");
            }
            //Write the log
            $logDBModel = new CarSalesLogModelDB();
            $logDBModel->created = $currentDateTime;
            $logDBModel->created_by = $dataUpdator;
            $logDBModel->log = 'File: "'.$fileDescription .'" deleted';
            $logDBModel->org_name = $orgName;
            $logDBModel->sales_no = $salesNo;
            $this->carsalesLogModel->AddLog($logDBModel);//Write the Log

		    header("location:".$url."&success=File Deleted#messageanchor");
            exit();

        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }   
    }

     /********** Update File Description FUNCTION. This will be called using Ajax so we will only return a string ******************/
     public function UpdateFileDescription()
     {
          //Check that the user is logged in
          if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
          {
            echo('Error: Please login to complete action');
            exit();
          }
 
          $dataUpdator = $_SESSION["UserName"];
 
         //check if this is a post Method
         if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            echo('Error: Invalid call. HTTP POST Required');
            exit();
         }
         
          
         try{
             if(!isset($_POST['sales_no']))
             {
                 throw new Exception('Sales No. was not passed in');
             }
             $salesNo = $_POST['sales_no'];
             //Now we have the sales no so we can modify the return URL
             $url = '/Views/CarSaleFile?SalesNo='.$salesNo;
             $orgName = $_SESSION['OrgName'];
             if(!isset($_POST['file_id']))
             {
                 throw new Exception('File Id was not passed in');
             }
             $fileId = $_POST['file_id'];
             if(!isset($_POST['description']))
             {
                 throw new Exception('File description was not passed in');
             }
             $description = $_POST['description'];
             $currentDateTime = gmdate("Y-m-d H:i:s");
             //Check the file exists
             $existingFile = $this->carsalesFileModel->GetFile($fileId,$salesNo,$orgName);
             if(count($existingFile) == 0)
             {
                 throw new Exception('File record does not exist');
             }
             $oldDescription = $existingFile[0]['description'];//Will be useful for logging later on
             //Update the File Description
             $rowCount = $this->carsalesFileModel->UpdateFileDescription($fileId,$salesNo,$orgName,$description);
             if($rowCount==0)
             {
                 throw new Exception("Failed to update the file description");
             }
             //Write the log
             $logDBModel = new CarSalesLogModelDB();
             $logDBModel->created = $currentDateTime;
             $logDBModel->created_by = $dataUpdator;
             $logDBModel->log = 'File Id:'.$fileId.' Description changed from "'.$oldDescription .'" to "'.$description .'"';
             $logDBModel->org_name = $orgName;
             $logDBModel->sales_no = $salesNo;
             $this->carsalesLogModel->AddLog($logDBModel);//Write the Log
 
             echo('File description updated');
             exit();
 
         }
         catch(Exception $e)
         {
            echo('Exception: ' .  $e->getMessage());
            exit();
         }   
     }
 
   
} 

$init = new CarSalesFileController();
/* We are going to server our View Requests which will all come via  GET method */
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $action = $_GET['action'];
    switch($action){
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}
else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
            case 'UploadFile':
                $init->UploadFile();
                break;
            case 'DeleteFile':
                $init->DeleteFile();
                break;
            case 'UpdateFileDescription':
                $init->UpdateFileDescription();
                break;
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}