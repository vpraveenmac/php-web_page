<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(dirname(__DIR__) . '/Models/LOVModel.php');
class ReferenceController
{
    private $lovModel;
    public function __construct() {
        $this->lovModel = new LOVModel();
    }
    /********** UPDATE REFERENCE FUNCTION ******************/
    public function UpdateReference()
    {
        $url = '/Views/ReferenceList';
        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            $_SESSION['error']='Invalid call. HTTP POST Required';
            header("location:" . $url . "#messageanchor");
            exit();

        }
        
        $data = [
            'id' => trim($_POST['id']),
            'type' => trim($_POST['type']),
            'val' => trim($_POST['val']),
            'info1' => trim($_POST['info1']),
            'info2' => trim($_POST['info2']),
            'info3' => trim($_POST['info3']),
            'info4' => trim($_POST['info4']),
            'longinfo1' => trim($_POST['longinfo1']),
            'comments' => trim($_POST['comments']),
            'active' => trim($_POST['active']),
            'QueryType' => trim($_POST['QueryType']),
        ];

        $url = $url . '?QueryType='.$data['QueryType'];
        
        
        //Check that the user is logged in
        if(!isset($_SESSION["UserName"])|| !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
        {
        {
            header("location:/Views/login?error=Please login to complete action#messageanchor");
            exit();
        }
 
         //only OrgAdmin and SuperUser can update the reference
        if(($_SESSION["AccessLevel"]!='OrgAdmin')&&($_SESSION["AccessLevel"]!='SuperUser'))
            $_SESSION['error'] = "Only an OrgAdmin/SuperUser can update the References";
            header("location::/index?#messageanchor");
             exit();

        }

        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }
        $currentDateTime = gmdate("Y-m-d H:i:s");
        //Org name
        $orgName = $_SESSION["OrgName"];
        $result = 0;
        try{
            $reference = new LOVDBClass();
            //first we get the existing value
            $existingData = $this->lovModel->getLOVByIdOrg($data['id'],$orgName);
           
            $reference->type=$data['type'];
            $reference->val=$data['val'];
            $reference->info1=$data['info1'];
            $reference->info2=$data['info2'];
            $reference->info3=$data['info3'];
            $reference->info4=$data['info4'];
            $reference->longinfo1=$data['longinfo1'];
            $reference->comments=$data['comments'];
            $reference->active=$data['active'];
            $reference->updated=$currentDateTime;
            $reference->updated_by=$dataUpdator;
            $reference->org_name = $orgName;
            if(count($existingData) == 0){
                //Entry was not found so we are going to create it
                $result = $this->lovModel->insertLOV($reference);
                if($result == 0){
                    throw new Exception("Failed to insert data");
                }
                header("location:".$url."&success=Reference created successfully#messageanchor");
            }
            else{
                //Entry was found so we are going to edit it
                $reference->id=$existingData[0]['id'];
                $result = $this->lovModel->updateOV($reference);
                if($result == 0){
                    throw new Exception("Failed to update data for Id: ".$reference->id);
                }
                header("location:".$url."&success=Reference updated successfully#messageanchor");
            }
            
        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }
        
    }
   
    /********** DELETE REFERENCE FUNCTION ******************/
    public function DeleteReference()
    {
        $data = [
            'id' => trim($_POST['id'])
        ];

        $url = '/Views/ReferenceList';
        //check if this is a post Method
        if ($_SERVER["REQUEST_METHOD"] != "POST") { 
            header("location:" . $url . "?error=Invalid call. HTTP POST Required#messageanchor");
            exit();

        }
        //Check that the user is logged in
        if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
        {
        {
            header("location:/Views/login?error=Please login to complete action#messageanchor");
            exit();
        }
 
         //only OrgAdmin and SuperUser can update the reference
        if(($_SESSION["AccessLevel"]!='OrgAdmin')&&($_SESSION["AccessLevel"]!='SuperUser'))
            $_SESSION['error'] = "Only an OrgAdmin/SuperUser can delete the References";
            header("location::/index?#messageanchor");
             exit();

        }

        $dataUpdator = "UNKNOWN";//Set the content updator
        if(isset($_SESSION["UserName"]))
        {
            $dataUpdator  = $_SESSION["UserName"] ;
        }
        //Org name
        $orgName = $_SESSION["OrgName"];
        $currentDateTime = gmdate("Y-m-d H:i:s");
        $result = 0;
        try{
            
            $id = $data['id'];
            //first we get the existing value
            $existingData = $this->lovModel->getLOVByIdOrg($id,$orgName);
            if(count($existingData) == 0){
                //Entry was not found
                throw new Exception('Reference with Id:'.$id.' was not found');
            }
            else{
                //Entry was found so we are going to delete it
                $id = $existingData[0]['id'];
                $result = $this->lovModel->deleteLOVOrg($id,$orgName);
                if($result == 0){
                    throw new Exception("Failed to delete reference with Id: ".$id);
                }
                header("location:".$url."?success=Reference deleted successfully#messageanchor");
            }
            
        }
        catch(Exception $e)
        {
            $_SESSION['error'] = "Exception: " .  $e->getMessage();
            header("location:".$url."#messageanchor");
             exit();
        }
        
    }
   

} 

 //Check that the user is logged in
 if(!isset($_SESSION["UserName"]) || !isset($_SESSION["AccessLevel"]) || !isset($_SESSION["OrgName"]))
  {
     header("location:/Views/login?error=Please login to complete action#messageanchor");
     exit();
 }

 //only OrgAdmin and SuperUser can update the reference
 if(($_SESSION["AccessLevel"]!='OrgAdmin')&&($_SESSION["AccessLevel"]!='SuperUser'))
 {
     $_SESSION['error'] = "Only an OrgAdmin/SuperUser can delete the References";
     header("location::/index?#messageanchor");
      exit();

 }
$init = new ReferenceController();
/* We are going to server our View Requests which will all come via  GET method */
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $action = $_GET['action'];
    switch($action){
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}
else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $action = $_POST['action'];
    switch($action){
            case 'UpdateReference':
                $init->UpdateReference();
                break;
            case 'DeleteReference':
                $init->DeleteReference();
                break;
        default:
        header("location:/index.php?error=Unknown action " . $action . " passed to controller");
        exit();
    }
}