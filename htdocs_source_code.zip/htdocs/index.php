﻿<?php 
include_once('header.php');
?>

<main id="main">
<?php
   if(isset($_GET['error'])){
    echo '<div class="row justify-content-center">';
    echo '<div class="col">';
    echo '<p class="bg-danger text-white p-2 text-center fs-5">';
    echo $_GET['error'];
    echo '</p>';
    echo '</div>';
    echo '</div>';
  }
  if(isset($_GET['success'])){
    echo '<div class="row justify-content-center">';
    echo '<div class="col">';
    echo '<p class="text-white bg-success p-2 text-center fs-5">';
    echo $_GET['success'];
    echo '</p>';
    echo '</div>';
    echo '</div>';
  }

?>
<div class="container-fluid">
  <div class="row justify-content-center py-4">
      <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12">
        <h1 class="display-3 shadow p-5 mb-5 bg-body rounded" style="font-family: Montserrat;font-weight:800;font-size:48;color:#6668b3">Online Sales Manager</h1>
        <p  class="display-6 shadow p-3 mb-5 bg-body rounded" style="font-family: Montserrat;font-weight:300;font-size:30;">A simple affordable stock/work management system for your car resale business needs.<br/><br/>
        Move from spreadsheets to a simple, intuitive online tool that allows you to collaborate with your business partners and keep a track of your inventory, expenses and grow your business.<br/>
       </p>
      </div>
      <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12">
        <img src="/assets/images/homepage_pic.png" alt="" class="img-fluid">
      </div>

  </div>
</div>
<?php 

include_once('footer.php');

?>
