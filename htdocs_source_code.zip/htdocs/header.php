﻿﻿<?php 
 session_start();
 
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html;" charset="utf-8" />
    <meta name="description" content="An online tool to manage your car sales">
    <meta name="keywords" content="carsales, online, manage, sales" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Carsales Manager | Your Online sales manager for used cars</title>
    <link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon" />

    <!-- Vendor CSS Files -->
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
   <!--

        width <768px  ** extra small devices such as mobile devices. Bootstrap provide "xs" to represent these devices.
        width >=768px and <992px ** small devices such as tablet devices. Bootstrap provide "sm" to represent these devices.
        width >=992px and <1200px **  medium devices such as laptop devices. Bootstrap provide "md" to represent these devices.
        width >=1200px **  large devices such as large desktop devices. Bootstrap provide "lg" symbol to represent these devices.
                -->

    <!-- Template Main CSS File -->
<link href="/assets/css/style.css?v=3" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<header id="header">
<div class="container-fluid  d-flex align-items-center justify-content-center">
 <div class="row">
    <div class="col d-flex">
        <a href="/index" class="logo"><img src="/assets/images/salesmanager-logo-sm.png" alt="" class="img">&nbsp;&nbsp;&nbsp;&nbsp;</a>
        <?php include_once('navbar.php'); ?> <!-- NAVBAR -->
    </div>
  </div>
</div> 
  
  
</header>
