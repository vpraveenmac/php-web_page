﻿<?php 
include_once('sublimelayoutheader.php');
?>
<style>
    table, th, td {
        border: 5px solid white;
    }
</style>
<div class="container-fluid ms-auto">
    <div class="row">
        <div class="col d-flex justify-content-center">
            <table style="width:1200px">
                <tbody>
                    <tr>
                        <td colspan="4">
                            <h2 class="padd-2">Some images from our work</h2>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <span style="font-size:medium">Toyota Kluger - Brand new car, marked and dented panel<br /></span>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <img src="/images/gallery/kluger1.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="Dent" />
                        </td>
                        <td>
                            <img src="/images/gallery/kluger3.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="work in progress" />
                        </td>
                        <td>
                            <img src="/images/gallery/kluger4.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="work in progress" />
                        </td>
                        <td>
                            <img src="/images/gallery/kluger5.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="Finished" />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4"><h2 class="padd-2"></h2></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <span style="font-size:medium">Mazda CX5 - Door dent, Stretched oversized dent<br /></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img src="/images/gallery/mazda1.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="Dent" />
                        </td>
                        <td>
                            <img src="/images/gallery/mazda2.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="work in progress" />
                        </td>
                        <td>
                            <img src="/images/gallery/mazda3.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="Finished" />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4"><h2 class="padd-2"></h2></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <span style="font-size:medium">Work Photos<br /></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img src="/images/gallery/work1.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="work" />
                        </td>
                        <td>
                            <img src="/images/gallery/work2.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="work" />
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4"><h2 class="padd-2"></h2></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <span style="font-size:medium">BMW - Boot Door dent, Stretched oversized dent<br /></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img src="/images/gallery/bmw1.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="damage" />
                        </td>
                        <td>
                            <img src="/images/gallery/bmw2.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="damage" />
                        </td>
                        <td>
                            <img src="/images/gallery/bmw3.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="fixed" />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4"><h2 class="padd-2"></h2></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <span style="font-size:medium">Toyota 86 - Massive Foot Sized dent<br /></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img src="/images/gallery/toyota1.jpg" style="border: 5px solid #000000;" height="300" width="300" alt="damage" />
                        </td>
                        <td>
                            <img src="/images/gallery/toyota2.jpg" style="border: 5px solid #FFFFFF;" height="300" width="300" alt="fixed" />
                        </td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php 
include_once('sublimelayoutfooter.php');
?>
