<?php
/**
 * CSV Export functionality using PHP.
 *
 * @author Mehul Gohil
 */

 function ExportPlainText($outputfilename,$dataarray)
 {
    // Start the output buffer.
    ob_start();

    // Set PHP headers for plaintext output.
    header('Content-Type: text/plain; charset=utf-8');
    header("Content-Disposition: attachment; filename=$outputfilename");
    
    // Clean up output buffer before writing anything to CSV file.
    ob_end_clean();

    // Create a file pointer with PHP.
    $output = fopen( 'php://output', 'w' );

    // Loop through the prepared data to output it to CSV file.
    foreach( $dataarray as $data ){
        fputcsv( $output, $data );
    }

    // Close the file pointer with PHP with the updated output.
    fclose( $output );
    exit;
 }