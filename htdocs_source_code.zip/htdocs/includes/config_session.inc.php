<?php
ini_set('session.use_only_cookies',1);
ini_set('session.use_strict_mode',1);
session_start();
$regenerateinterval = 60 * 55;
$interval = 60 * 60;
// Check if the last_timestamp is set
// and last_timestamp is greater then 15 minutes or 9000 seconds
// then unset $_SESSION variable & destroy session data
if (isset($_SESSION['last_regeneration']) && (time() - $_SESSION['last_regeneration']) > $interval) {
    //Save the redirect URL session variable
    $redirecturl='';
    if(isset($_SESSION['redirect_url'])){
        $redirecturl = $_SESSION['redirect_url'];
    }
    session_unset();
    session_destroy();
    //Start a new session
    session_start();
    $_SESSION['redirect_url']=$redirecturl;//Set the redirect URL into the session variable

    //Redirect user to login page
    header("Location:/Views/login?error=Session expired. Please re-login");
    exit();
  }
  else{
    
    /* If User is Logged in, we will try to increase the timer on the session */
    if(isset($_SESSION['UserName'])){ /* User is Logged in */
        if(!isset($_SESSION['last_regeneration'])){
            regenerate_session_id_loggedin();
        }
        else{
        
            if(time() - $_SESSION['last_regeneration'] >= $regenerateinterval)
            {
                regenerate_session_id_loggedin();
            }
        }
    }
    /* If user is not logged in we will send them to the login page */
    else
    {
        header("location:/Views/login?error=Restricted action attempted. Please login first");
    }
  }
  


function regenerate_session_id()
{
    $userName='';
    $orgName = '';
    $accessLevel = '';

    if(isset($_SESSION['UserName'])){
        $userName=$_SESSION['UserName'];
    }
    if(isset($_SESSION['OrgName'])){
        $orgName = $_SESSION["OrgName"];
    }
    if(isset($_SESSION['AccessLevel'])){
        $accessLevel = $_SESSION["AccessLevel"];
    }

    session_regenerate_id(true);
  
    $newSessionId = session_create_id();//new session id
    $sessionId = $newSessionId . $userName; //append refereeId to the session Id
    session_id($sessionId);//Set the session Id
    $_SESSION['UserName'] = $userName;
    $_SESSION['OrgName'] = $orgName;
    $_SESSION['AccessLevel'] = $accessLevel;
    
    
}
function regenerate_session_id_loggedin()
{
    $userName='';
    $orgName = '';
    $accessLevel = '';

    if(isset($_SESSION['UserName'])){
        $userName=$_SESSION['UserName'];
    }
    if(isset($_SESSION['OrgName'])){
        $orgName = $_SESSION["OrgName"];
    }
    if(isset($_SESSION['AccessLevel'])){
        $accessLevel = $_SESSION["AccessLevel"];
    }

    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
    $_SESSION['UserName'] = $userName;
    $_SESSION['OrgName'] = $orgName;
    $_SESSION['AccessLevel'] = $accessLevel;
}