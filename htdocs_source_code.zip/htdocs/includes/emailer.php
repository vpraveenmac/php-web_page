<?php
use PHPMailer\PHPMailer\PHPMailer;
include_once '../PHPMailer/src/PHPMailer.php';
include_once '../PHPMailer/src/Exception.php';
include_once '../PHPMailer/src/SMTP.php';


class Emailer extends PHPMailer{
    private $sendername;
    private $replytoemail;
    private $subject;
    private $message;
    private $tolist;
    private $cclist;
    private $bcclist;

    private $smtpHost = 'smtp.hostinger.com';
    private $smtpUser = 'no-reply@onlinesalesmanager.com.au';
    private $smtpPassword = 'm98XxJ^kRz';
    private $smtpPort = 587;
    private $debug;
    public function __construct($replytoemail,$sendername,$subject,$message,$tolist,$cclist,$bcclist,$debug = 0){
         $this->sendername=$sendername;
         $this->subject=$subject;
         $this->message=$message;
         $this->tolist=$tolist;
         $this->cclist=$cclist;
         $this->bcclist=$bcclist;
         $this->replytoemail=$replytoemail;
         $this->debug = $debug;
    }
    public function SendEmail()
    {
        try
        {
            $mail = new PHPMailer(true);
            $mail->SMTPDebug = $this->debug;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = $this->smtpHost;                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = $this->smtpUser;                     //SMTP username
            $mail->Password   = $this->smtpPassword;                               //SMTP password
            //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = $this->smtpPort;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            $mail->setFrom($this->smtpUser, $this->sendername);
            $mail->addReplyTo($this->replytoemail,$this->sendername);
            //The To List will be an array
            if(!empty($this->tolist))
            {
                foreach($this->tolist as $email)
                {
                    if(!empty($email))
                    {
                        $mail->addAddress($email);
                    }
                }
            }

            //The CC List will be an array
            if(!empty($this->cclist))
            {
                foreach($this->cclist as $email)
                {
                    if(!empty($email))
                    {
                        $mail->addCC($email);
                    }
                }
            }

            //The BCC List will be an array
            if(!empty($this->bcclist))
            {
                foreach($this->bcclist as $email)
                {
                    if(!empty($email))
                    {
                        $mail->addBCC($email);
                    }
                }
            }

            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

            //Content
            $mail->isHTML(true);      //Set email format to HTML
            $mail->Subject = $this->subject;
            $mail->Body    = $this->message;
          // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            return("SUCCESS");
        } 
        catch (Exception $e) 
        {
            return($mail->ErrorInfo);
        }
    }

}
