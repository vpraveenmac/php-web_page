<?php
class CarsalesDataConnection{
    /* private $host='a2nlmysql13plsk.secureserver.net';
    private $dbname='sublime_jobs';
    private $dbuser='webuser';
    private $dbpass = 'Subl1meDB!'; */
    private $host='localhost';
    private $dbname='sales_manager';
    private $dbuser='webuser';
    private $dbpass = 'Subl1meLocal';

    public function connect()
    {
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbname;
        $pdo = new PDO($dsn,$this->dbuser,$this->dbpass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
        return $pdo;
    }
}

