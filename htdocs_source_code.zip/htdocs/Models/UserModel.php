 <?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');
class UserModelDB
    {
        public $id;
        public $username;
        public $password;
        public $active;
        public $fullname;
        public $email;
        public $lastlogin;
        public $updatedby;
        public $updated;
    }

    class UserOrgModelDB
    {
        public $id;
        public $username;
        public $orgname;
        public $accesslevel;
        public $active;
        public $updatedby;
        public $updated;
    }
class UserModel extends CarsalesDataConnection
{
    public function GetAllUsers(){
        $sql = "SELECT * from user";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetAllUsersByOrg($orgname){
        $sql = "SELECT usr.*,org.org_name,org.accesslevel from user usr inner join user_org org on  usr.username = org.username where org.org_name=?";
        if(empty($orgname))
        {
            $sql = "SELECT usr.*,org.org_name,org.accesslevel from user usr inner join user_org org on  usr.username = org.username";
        }
        
        $stmt = $this->connect()->prepare($sql);
        if(empty($orgname))
        {
            $stmt->execute();
        }
        else
        {
            $stmt->execute([$orgname]);
        }
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetUserDetailByNameOrg($username,$org){
        $sql = "SELECT usr.*,org.org_name,org.accesslevel from user usr inner join user_org org on  usr.username = org.username where usr.username=? and org.org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username,$org]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetUserDetailById($id){
      //  $sql = "SELECT * from user where id=?";
        $sql = "SELECT usr.*,org.org_name,org.accesslevel from user usr inner join user_org org on  usr.username = org.username where usr.id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$id]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetUserByName($username){
        $sql = "SELECT * from user where username=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetAllUserDetails(){
        $sql = "SELECT usr.*,org.org_name,org.accesslevel from user usr inner join user_org org on  usr.username = org.username ";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetAllActiveUserDetails(){
        $sql = "SELECT usr.*,org.org_name,,org.accesslevel from user usr inner join user_org org on  usr.username = org.username  where usr.active='Y'";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }


    public function setLoginTS($datetime,$username){
        $sql = "UPDATE user set last_login=? where username=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$datetime,$username]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function setPassword($hashedPassword,$username,$currentDateTime,$dataUpdator){
        $sql = "UPDATE user set password=?,updated_by=?,updated=? where username=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$hashedPassword,$dataUpdator,$currentDateTime,$username]);
        $count = $stmt->rowCount();
        return $count;

    }
    public function AddUser(UserModelDB $user){
        $sql = "INSERT INTO user(username,active,fullname,email,updated,updated_by,password) values (?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$user->username,$user->active,$user->fullname,$user->email,$user->updated,$user->updatedby,$user->password]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function CheckUserOrg($username,$orgname){
        $sql = "SELECT * from user_org  where username=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username,$orgname]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function AddUserOrg(UserOrgModelDB $userorg){
        $sql = "INSERT INTO user_org(username,org_name,accesslevel,active,updated,updated_by) values (?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$userorg->username,$userorg->orgname ,$userorg->accesslevel,$userorg->active,$userorg->updated,$userorg->updatedby]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function UpdateUserOrg(UserOrgModelDB $userorg){
        $sql = "UPDATE user_org set accesslevel=?,active=?,updated=?,updated_by=? where username=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$userorg->accesslevel,$userorg->active,$userorg->updated,$userorg->updatedby,$userorg->username,$userorg->orgname]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function DeleteUserById($id){
        $sql = "DELETE FROM  user where id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$id]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function DeleteUserOrg($username,$orgname){
        $sql = "DELETE FROM  user_org where username=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username,$orgname]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function UpdateUser(UserModelDB $user){
        $sql = "UPDATE user set username=?,active=?,fullname=?,email=?,updated=?,updated_by=? WHERE id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$user->username,$user->active,$user->fullname,$user->email,$user->updated,$user->updatedby,$user->id]);
        $count = $stmt->rowCount();
        return $count;

    }
  

}