<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');
class CarSalesModelDB
{
    public $sales_no;
    public $created;
    public $created_by;
    public $updated;
    public $updated_by;
    public $car_make;
    public $car_model;
    public $car_color;
    public $car_year;
    public $car_rego;
    public $transmission;
    public $rego_expiry;
    public $mileage;
    public $specifications;
    public $ADED;
    public $purchase_date;
    public $purchase_price;
    public $sold_price;
    public $sold_date;
    public $profit;
    public $sale_status;
    public $damage;
    
    public $notes;
    public $stock_location;
    public $date_advertised;
    public $transferred;
    public $sales_person;
    public $total_expenses;
    public $gst;
    public $workitem_list;
    public $org_name;
    public $fuel_type;
    public $work_scheduled_date;
    public $stock_owner;
}
class ExpenseProfitGST
{
    public $profit;
    public $totalExpenses;
    public $gst;
}


class CarSalesModel extends CarsalesDataConnection
{
    public function GetAllSales(){
        $sql = "SELECT * from carsales";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetSalesDetailBySalesNoOrg($salesNo,$org_name){
        $sql = "SELECT * from carsales where sales_no=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$salesNo,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetSalesDetailByQuery($query){
        $stmt = $this->connect()->prepare($query);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetSalesByStatusOrg($status,$org_name){
        $sql = "SELECT * from carsales where sale_status=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$status,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }



    public function GetSalesByWorkItemOrg($workitem,$org_name){
        $sql = "SELECT * from carsales where sale_status != 'Sold' and workitem_list like ? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute(['%'.$workitem.'%',$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetActiveSalesByScheduledDate($work_scheduled_date,$org_name){
        $sql = "SELECT * from carsales where sale_status != 'Sold' and sale_status != 'Deleted' and work_scheduled_date=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$work_scheduled_date,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    

    public function UpdateSalesStatusBySalesNoOrg($sales_no,$org_name,$status,$updated,$updated_by){
        $sql = "update carsales set sale_status=?,updated=?,updated_by=? where sales_no=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$status,$updated,$updated_by,$sales_no,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    }


    public function UpdateExpenseProfitGST($sales_no,$org_name,$expense,$profit,$gst,$updated,$updated_by){
        $sql = "update carsales set total_expenses=?,profit=?,gst=?,updated=?,updated_by=? where sales_no=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$expense,$profit,$gst,$updated,$updated_by,$sales_no,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    }

    public function AddCarSale(CarSalesModelDB $sale){
        $sql = "INSERT INTO carsales(
        org_name,created,created_by,updated,updated_by,car_make,car_model,
        car_color,car_year,car_rego,transmission,rego_expiry,mileage,specifications,ADED,purchase_date,purchase_price,sold_price,sold_date,
        profit,sale_status,damage,notes,stock_location,date_advertised,transferred,sales_person,total_expenses,gst,workitem_list,fuel_type,work_scheduled_date,stock_owner) 
        values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $conn = $this->connect();
        $stmt = $conn->prepare($sql);
        $stmt->execute([$sale->org_name,$sale->created,$sale->created_by,$sale->updated,$sale->updated_by,$sale->car_make,$sale->car_model,$sale->car_color,
        $sale->car_year,$sale->car_rego,$sale->transmission,$sale->rego_expiry,$sale->mileage,$sale->specifications,$sale->ADED,$sale->purchase_date,
        $sale->purchase_price,$sale->sold_price,$sale->sold_date,$sale->profit,$sale->sale_status,$sale->damage,$sale->notes,$sale->stock_location,$sale->date_advertised,
        $sale->transferred,$sale->sales_person,$sale->total_expenses,$sale->gst,$sale->workitem_list,$sale->fuel_type,$sale->work_scheduled_date,$sale->stock_owner]);
        $lastSalesNo = $conn->lastInsertId();//Get the last inserted ID which is the salesNo
        return($lastSalesNo);

    }

    public function UpdateCarSale(CarSalesModelDB $sale){
        $sql = "UPDATE carsales SET org_name=?,created=?,created_by=?,updated=?,updated_by=?,car_make=?,car_model=?,
        car_color=?,car_year=?,car_rego=?,transmission=?,rego_expiry=?,mileage=?,specifications=?,ADED=?,purchase_date=?,purchase_price=?,sold_price=?,sold_date=?,
        profit=?,sale_status=?,damage=?,notes=?,stock_location=?,date_advertised=?,transferred=?,sales_person=?,total_expenses=?,gst=?,workitem_list=?,fuel_type=?,work_scheduled_date=?,stock_owner=? WHERE sales_no=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sale->org_name,$sale->created,$sale->created_by,$sale->updated,$sale->updated_by,$sale->car_make,$sale->car_model,$sale->car_color,
        $sale->car_year,$sale->car_rego,$sale->transmission,$sale->rego_expiry,$sale->mileage,$sale->specifications,$sale->ADED,$sale->purchase_date,
        $sale->purchase_price,$sale->sold_price,$sale->sold_date,$sale->profit,$sale->sale_status,$sale->damage,$sale->notes,$sale->stock_location,$sale->date_advertised,
        $sale->transferred,$sale->sales_person,$sale->total_expenses,$sale->gst,$sale->workitem_list,$sale->fuel_type,$sale->work_scheduled_date,$sale->stock_owner,$sale->sales_no]);
        
        $count = $stmt->rowCount();
        return $count;

    }
  
}