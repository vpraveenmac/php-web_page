<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');

class CarSalesFileModelDB
{
    public $id;
    public $sales_no;
    public $created;
    public $created_by;
    public $data;
    public $description;
    public $mime_type;
    public $org_name;
}


class CarSalesFileModel extends CarsalesDataConnection
{
    
    public function GetSalesFilesBySalesNoOrg($sales_no,$org_name){
        $sql = "SELECT * from carsales_file where sales_no=? and org_name=? order by created desc";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetFile($fileid,$salesNo,$org_name){
        $sql = "SELECT * FROM carsales_file where id=? and sales_no=? and org_name=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$fileid,$salesNo,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function AddFile(CarSalesFileModelDB $file){
        $sql = "INSERT INTO carsales_file(sales_no,created,created_by,data,description,mime_type,org_name) values (?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$file->sales_no,$file->created,$file->created_by,$file->data,$file->description,$file->mime_type,$file->org_name]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function UpdateFile(CarSalesFileModelDB $file){
        $sql = "UPDATE carsales_file SET org_name=?,created=?,created_by=?,data=?,description=?,mime_type=?,sales_no=? WHERE id=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$file->org_name,$file->created,$file->created_by,$file->data,$file->description,$file->mime_type,$file->id]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function DeleteFile($fileid,$salesNo,$org_name)
    {
        $sql = "DELETE FROM carsales_file where id=? and sales_no=? and org_name=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$fileid,$salesNo,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    }

    public function UpdateFileDescription($fileid,$salesNo,$org_name,$description)
    {
        $sql = "UPDATE carsales_file SET description = ? where id=? and sales_no=? and org_name=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$description,$fileid,$salesNo,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    }


}