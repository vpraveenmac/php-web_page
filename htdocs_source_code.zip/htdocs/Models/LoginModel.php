<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');

class LoginModel extends CarsalesDataConnection
{
   
    public function getResetToken($selector){
        $sql = "SELECT * from auth_tokens where selector=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$selector]);
        $results = $stmt->fetchAll();
        return $results;

    }


   
    public function deleteResetToken($username){
        $sql = "DELETE from auth_tokens where username=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function insertResetToken($username,$selector,$hashvalidator,$expires){
        $sql = "INSERT INTO auth_tokens(username,selector,hashedvalidator,expires) values (?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$username,$selector,$hashvalidator,$expires]);
        $count = $stmt->rowCount();
        return $count;

    }

   

}