<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');

class CarSalesLogModelDB
{
    public $id;
    public $sales_no;
    public $created;
    public $created_by;
    public $log;
    public $org_name;
}

class CarSalesLogModel extends CarsalesDataConnection
{
    
    public function GetSalesLogsBySalesNoOrg($sales_no,$org_name){
        $sql = "SELECT * from carsales_log where sales_no=? and org_name=? order by created desc";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function AddLog(CarSalesLogModelDB $log){
        $sql = "INSERT INTO carsales_log(sales_no,created,created_by,log,org_name) values (?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$log->sales_no,$log->created,$log->created_by,$log->log,$log->org_name]);
        $count = $stmt->rowCount();
        return $count;

    }


}