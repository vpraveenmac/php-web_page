<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');

class CarSalesNoteModelDB
{
    public $id;
    public $sales_no;
    public $created;
    public $created_by;
    public $note;
    public $org_name;
}

class CarSalesNoteModel extends CarsalesDataConnection
{
    public function GetSalesNotesBySalesNoOrg($sales_no,$org_name){
        $sql = "SELECT * from carsales_note where sales_no=? and org_name=? order by created desc";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetSalesNotesBySalesNoOrgLimit5($sales_no,$org_name){
        $sql = "select * from carsales_note where sales_no=? and org_name=? order by created desc limit 5";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function AddNote(CarSalesNoteModelDB $note){
        $sql = "INSERT INTO carsales_note(sales_no,created,created_by,note,org_name) values (?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$note->sales_no,$note->created,$note->created_by,$note->note,$note->org_name]);
        $count = $stmt->rowCount();
        return $count;

    }

}