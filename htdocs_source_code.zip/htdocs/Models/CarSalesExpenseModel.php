<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');

class CarSalesExpenseModelDB
{
    public $id;
    public $sales_no;
    public $created;
    public $created_by;
    public $expense_type;
    public $expense_value;
    public $expense_by;
    public $org_name;
}

class CarSalesExpenseModel extends CarsalesDataConnection
{
    
    public function GetSalesExpensesByIdSalesNoOrg($expense_id,$sales_no,$org_name){
        $sql = "SELECT * from carsales_expense where id=? and sales_no=? and org_name=? order by created desc";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$expense_id,$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }
    public function GetSalesExpensesBySalesNoOrg($sales_no,$org_name){
        $sql = "SELECT * from carsales_expense where sales_no=? and org_name=? order by created desc";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$sales_no,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function AddExpense(CarSalesExpenseModelDB $expense){
        $sql = "INSERT INTO carsales_expense(sales_no,created,created_by,expense_type,expense_value,expense_by,org_name) values (?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$expense->sales_no,$expense->created,$expense->created_by,$expense->expense_type,$expense->expense_value,$expense->expense_by,$expense->org_name]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function DeleteExpense($expenseid,$sales_no,$org_name)
    {
        $sql = "DELETE FROM carsales_expense where id=? and sales_no=? and org_name=?"; 
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$expenseid,$sales_no,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    }


}