<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');
class LOVDBClass
{
    public $id;
    public $type;
    public $val;
    public $info1;
    public $info2;
    public $info3;
    public $info4;
    public $comments;
    public $longinfo1;
    public $updated;
    public $updated_by;
    public $active;
    public $org_name;
}

class CarsalesModelUI
{
    public $StatusCodes;
    public $CarMakeCodes;
    public $TransmissionCodes;
    public $StockLocationCodes;
    public $TransferredCodes;
    public $SalesPersonCodes;
    public $WorkItemCodes;
    public $FuelTypeCodes;
    public $ExpenseTypeCodes;
}

class LOVModel extends CarsalesDataConnection
{
  
    public function getAllLOVByOrg($org_name){
        $sql = "SELECT * from lst_of_val where org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }
    

    public function getOrgAdminLOVByOrg($org_name){
        $sql = "SELECT * from lst_of_val where org_name=? and type not in ('CarsalesQuery','Email_Config')";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function getLOVByIdOrg($id,$org_name){
        $sql = "SELECT * from lst_of_val where id=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$id,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }


    public function getLOVByTypeOrg($refType,$org_name){
        $sql = "SELECT * from lst_of_val where type=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$refType,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function getActiveLOVByTypeOrg($refType,$org_name){
        $sql = "SELECT * from lst_of_val where type=? and active='Y'  and org_name=? order by id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$refType,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }
    public function getActiveLOVByTypeValueOrg($refType,$val,$org_name){
        $sql = "SELECT * from lst_of_val where type=? and val=? and active='Y'  and org_name=? order by id";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$refType,$val,$org_name]);
        $results = $stmt->fetchAll();
        return $results;

    }

   
    public function insertLOV(LOVDBClass $ref)
    {
        $sql = "INSERT INTO lst_of_val (type,val,info1,info2,info3,info4,comments,longinfo1,updated,updated_by,active,org_name) 
        values (?,?,?,?,?,?,?,?,?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([
        $ref->type,
        $ref->val,
        $ref->info1,
        $ref->info2,
        $ref->info3,
        $ref->info4,
        $ref->comments,
        $ref->longinfo1,
        $ref->updated,
        $ref->updated_by,
        $ref->active,
        $ref->org_name
        ]);
        $count = $stmt->rowCount();
        return $count;
    } 

    public function updateOV(LOVDBClass $ref)
    {
        $sql = "UPDATE lst_of_val set type=?,val=?,info1=?,info2=?,info3=?,info4=?,comments=?,longinfo1=?,updated=?,updated_by=?,active=?,org_name=? where id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([
        $ref->type,
        $ref->val,
        $ref->info1,
        $ref->info2,
        $ref->info3,
        $ref->info4,
        $ref->comments,
        $ref->longinfo1,
        $ref->updated,
        $ref->updated_by,
        $ref->active,
        $ref->org_name,
        $ref->id
        ]);
        $count = $stmt->rowCount();
        return $count;
    } 
    public function activateLOV($id,$updated,$updated_by)
    {
        $sql = "UPDATE lst_of_val set active='Y',updated = ?,updatedby = ? where id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$updated,$updated_by,$id]);
        $count = $stmt->rowCount();
        return $count;
    } 

    public function deleteLOVOrg($id,$org_name)
    {
        $sql = "DELETE FROM lst_of_val where id=? and org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$id,$org_name]);
        $count = $stmt->rowCount();
        return $count;
    } 

    public function CreateCarsalesModelUI($org_name)
    {
        $sql = "SELECT * from lst_of_val where type in ('CarMake','Transmission','StockLocation','CarsalesStatus','Transferred','CarsalesWorkItem','SalesPerson','FuelType','Expense') and active='Y'  and org_name=? order by type,val";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$org_name]);
        $results = $stmt->fetchAll();
        $StatusCodes = array();
        $CarMakeCodes = array();
        $TransmissionCodes = array();
        $StockLocationCodes = array();
        $TransferredCodes = array();
        $SalesPersonCodes = array();
        $SalesPersonNames = array();
        $WorkItemCodes = array();
        $FuelTypeCodes = array();
        $ExpenseTypeCodes = array();
        //Get the Org Users to add as sales person
        $sql = "SELECT usr.*,org.org_name from user usr inner join user_org org on  usr.username = org.username where org.org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$org_name]);
        $orgUsers = $stmt->fetchAll();

        //Push the name value pair to the query name list array
        foreach($results as $item)
        {
            switch ($item['type'])
            {
                case 'CarMake':
                    array_push(
                        $CarMakeCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'CarsalesStatus':
                    array_push(
                        $StatusCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'Transmission':
                    array_push(
                        $TransmissionCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'StockLocation':
                    array_push(
                        $StockLocationCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'Transferred':
                    array_push(
                        $TransferredCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'SalesPerson':
                    array_push(
                        $SalesPersonCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    array_push($SalesPersonNames,strtolower($item['val']));//add to te 1-D array of names
                    break;
                case 'CarsalesWorkItem':
                    array_push($WorkItemCodes,$item['val']);
                    break;
                case 'FuelType':
                    array_push(
                        $FuelTypeCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
                case 'Expense':
                    array_push(
                        $ExpenseTypeCodes,array('text'=>$item['val'],'val'=>$item['val'])
                    );
                    break;
            }
            
            
        }
        //Add the Users to teh salesperson list if it doesn't exist
        foreach($orgUsers as $user)
        {
            if (in_array(strtolower($user['username']), $SalesPersonNames)) {
                //Do nothing as it already exists
            }
            else
            {
                array_push(
                    $SalesPersonCodes,array('text'=>ucwords(strtolower($user['username'])),'val'=>ucwords(strtolower($user['username'])))
                );
            }

        }
        $returnModel = new CarsalesModelUI();
        $returnModel->CarMakeCodes = $CarMakeCodes;
        $returnModel->StatusCodes = $StatusCodes;
        $returnModel->TransmissionCodes = $TransmissionCodes;
        $returnModel->StockLocationCodes = $StockLocationCodes;
        $returnModel->TransferredCodes = $TransferredCodes;
        $returnModel->SalesPersonCodes = $SalesPersonCodes;
        $returnModel->WorkItemCodes = $WorkItemCodes;
        $returnModel->FuelTypeCodes = $FuelTypeCodes;
        $returnModel->ExpenseTypeCodes = $ExpenseTypeCodes;
        return($returnModel);


       
    }
}