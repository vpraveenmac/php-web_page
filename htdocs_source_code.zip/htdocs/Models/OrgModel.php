<?php
include_once(dirname(__DIR__) . '/includes/CarsalesDataConnection.php');
class OrgDetailModel
    {
        public $id;
        public $orgName;
        public $active;
        public $updatedBy;
        public $updated;
    }
class OrgModel extends CarsalesDataConnection
{
    public function GetAllOrgs(){
        $sql = "SELECT * from org_detail";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetAllActiveOrgs(){
        $sql = "SELECT * from org_detail  where active='Y'";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetOrgDetailById($id){
        $sql = "SELECT * from org_detail  where id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$id]);
        $results = $stmt->fetchAll();
        return $results;

    }

    public function GetOrgDetailByName($orgname){
        $sql = "SELECT * from org_detail  where org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$orgname]);
        $results = $stmt->fetchAll();
        return $results;

    }



    public function AddOrg(OrgDetailModel $Org){
        $sql = "INSERT INTO org_detail(org_name,active,updated,updated_by) values (?,?,?,?)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$Org->orgName,$Org->active,$Org->updated,$Org->updatedBy]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function DeleteOrg($orgname){
        $sql = "DELETE FROM  org_detail where org_name=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$orgname]);
        $count = $stmt->rowCount();
        return $count;

    }

    public function UpdateOrg(OrgDetailModel $Org){
        $sql = "UPDATE org_detail set org_name=?,active=?,updated=?,updated_by=? where id=?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$Org->orgName,$Org->active,$Org->updated,$Org->updatedBy,$Org->id]);
        $count = $stmt->rowCount();
        return $count;

    }

   

}