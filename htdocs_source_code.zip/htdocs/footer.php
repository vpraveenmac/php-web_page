﻿﻿</main>  
   
    <!-- Vendor JS Files -->
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Template Main JS File -->
    <script src="/assets/js/main.js"></script>
    <script src="/assets/js/carsalesmainscripts.js"></script>

    
    

<footer class="footer mt-auto py-3 bg-body-tertiary">
  <div class="container-fluid">
    <div class="row">
        <div class="col">
        
        </div>
    </div>
  </div>
</footer>
</body>
</html>
