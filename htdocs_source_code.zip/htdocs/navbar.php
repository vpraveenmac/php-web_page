 <!-- Navbar Start -->
 <nav id="navbar" class="navbar">
      <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      <!-- <button class="mobile-nav-toggle" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      
        <ul class="nav menu">
          <li><a id="navbar-home" class="nav-link scrollto" href="/index">Home</a></li>
          <li><a id="navbar-aboutus" class="nav-link scrollto" href="#">About us</a></li>
          <li><a id="navbar-pricing" class="nav-link scrollto" href="#">Pricing</a></li>
          <li><a id="navbar-demo" class="nav-link scrollto" href="#">Demo</a></li>
        <?php 
        /* Show members area if logged in  */
          if((isset($_SESSION["UserName"]))&&(isset($_SESSION["OrgName"])))
          { 
            echo '<li id="navbar-memberarea" class="dropdown"><a href="#" ><span>Members Area</span> <i class="bi bi-chevron-down"></i></a>';
              echo '<ul>';
                echo '<li><a href="/Views/SalesList" target="saleslist">Sales</a></li>';
                echo '<li><a href="/Views/updatepassword">Password</a></li>';
              echo '</ul>';
           echo '</li>';
          }
          /* Show Admin area if logged in and is an admin */
          if((isset($_SESSION["UserName"]))&&(isset($_SESSION["OrgName"]))&&(isset($_SESSION["AccessLevel"])))
          {
            if(($_SESSION["AccessLevel"] == "SuperUser")||($_SESSION["AccessLevel"]=="OrgAdmin"))
            { 
              echo '<li id="navbar-administration" class="dropdown"><a href="#"><span>Administration</span> <i class="bi bi-chevron-down"></i></a>';
                echo '<ul>';
                  echo '<li><a href="/Views/ReferenceList">Reference</a></li>';
                  if($_SESSION["AccessLevel"] == "SuperUser")
                  {
                    echo '<li><a href="/Views/OrgList">Organisation</a></li>';
                    echo '<li><a href="/Views/UserList">Users</a></li>';
                    echo '<li><a href="/Views/GamesList">Email</a></li>';
                  }
                echo '</ul>';
             echo '</li>';
            }
          }
          
          /* Login or Logout link */
          if((isset($_SESSION["UserName"]))&&(isset($_SESSION["OrgName"])))
          {
           echo '<li ><a class="nav-link" href="/Controllers/LoginController.php?action=Logout"><i class="bi bi-box-arrow-right" style="font-size: 1.5rem;"></i></a></li>';
          }
          else
          { 
            echo '<li ><a class="nav-link" href="/Views/login">Login</a></li>';
          } 
          /* Show logged in user details if logged in  */
          if((isset($_SESSION["UserName"]))&&(isset($_SESSION["OrgName"])))
          {
              echo '<li>';
              //echo '<svg height="40" width="150" >';
             // echo '<rect width="100%" height="100%" stroke="#124265" stroke-width="1" fill="#eee" rx="10px" ry="10px" stroke-linejoin="round" />';
              //echo '<text x="50%" y="50%" text-anchor="middle" fill="#fff" font-size="13px" font-family="Arial" dy=".3em">';
              echo $_SESSION["UserName"] . ' [' . $_SESSION["OrgName"].']';
              //echo '</text>';
              //echo '</svg>';
              echo '</li>';
          } 
        ?>

        
     </ul>
     <i class="bi bi-list mobile-nav-toggle"></i>
      
  </nav>

    <!-- Navbar End -->

    