<?php 
include_once('carsalesheader.php');
  include_once('../Models/LOVModel.php');
  $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
  
  //Check Authorisation
  if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
  {
      if(($_SESSION["AccessLevel"]!='OrgAdmin')&&($_SESSION["AccessLevel"]!='SuperUser'))
      {
            echo "<script>parent.self.location='/index.php?error=Unauthorised attempt to view/edit data#messageanchor';</script>";
            exit();
      }
  }
  else{
        echo "<script>parent.self.location='/Views/login?error=Please login to view data#messageanchor';</script>";
        exit();
  }
  //Org name
  $orgName = $_SESSION["OrgName"];
  $lovmodel = new LOVModel();
  $referencelistresults = array();

    //Check if the Query Type was passed in. This will allow us to narrow down the search and make the results load faster
    $queryType ='';
    if(isset($_GET['QueryType']))
    {
        $queryType = $_GET['QueryType'];
    }
    //Only the SUperUser is allowed to query 'CarsalesQuery','Email_Config' Types so we will send back an error if such a thing was requested
    if(($queryType =='CarsalesQuery')||($queryType =='Email_Config'))
    {
        if($_SESSION["AccessLevel"] !='SuperUser')
        {
            $_SESSION['error'] = 'Only a super user can view/edit the References with Type:"'.$queryType.'"';
            echo "<script>parent.self.location='/Views/ReferenceList#messageanchor';</script>";
            exit();
        }
    }

    if($queryType !='')
    {
        $referencelistresults = $lovmodel->getLOVByTypeOrg($queryType,$orgName);
    }
    else if($_SESSION["AccessLevel"] =='SuperUser')
    {
        $referencelistresults = $lovmodel->getAllLOVByOrg($orgName);
    } 
    else
    {
        $referencelistresults = $lovmodel->getOrgAdminLOVByOrg($orgName);
    }


?>
<main id="main">
    <a name="messageanchor"></a>
    <div class="container-fluid">

        <?php
        if(isset($_SESSION['error'])&&($_SESSION['error']!=''))
        {
          echo '<div class="row justify-content-center">';
          echo '<div class="col">';
          echo '<p class="bg-danger text-white p-2 text-center fs-5">';
          echo $_SESSION['error'];
          echo '</p>';
          echo '</div>';
          echo '</div>';
          $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
      }
      if(isset($_GET['success'])&&($_GET['success']!='')){
          echo '<div class="row justify-content-center">';
          echo '<div class="col">';
          echo '<p class="text-white bg-success p-2 text-center fs-5">';
          echo $_GET['success'];
          echo '</p>';
          echo '</div>';
          echo '</div>';
      }
        
        ?>
        <!-- ***************************************************** -->
        <!-- ***************** Query ********************* -->
        <!-- ***************************************************** -->
        <form action="/Views/ReferenceList" id="searchform" method="get">
        <fieldset class="border rounded-2 p-2">
        <legend class="float-none w-auto px-0 py-3" >Search Reference</legend>
        <div class="row justify-content-start py-0">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Type</span>
                    <input type="text" class="form-control-sm" id="SearchQueryType" name="QueryType" value="<?php echo $queryType; ?>"/>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <input class="btn btn-secondary" type="submit" value="Query"/>
                </div>
            </div>
        </div>
        </fieldset>
        </form>
        <!-- ***************************************************** -->
        <!-- ***************** ADD / EDIT ********************* -->
        <!-- ***************************************************** -->
        <form action="/Controllers/ReferenceController.php" id="editform" method="post">
        <fieldset class="border rounded-2 p-2">
        <legend class="float-none w-auto px-0 py-3" >Add/Edit Reference</legend>
        <div class="row justify-content-start py-0">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Id</span>
                    <input type="text" class="form-control-sm" disabled id="id_display" value=""/>
                    <input type="hidden" id="id" name="id" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Type</span>
                    <input type="text" class="form-control-sm" required id="type" name="type" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Val</span>
                    <input type="text" class="form-control-sm" required id="val" name="val" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Active</span>
                    <select class="form-select-sm" required name="active" id="active">
                        <option value="Y">Y</option>
                        <option value="N">N</option>
                    </select>
                </div>
            </div>
       
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Info1</span>
                    <input type="text" class="form-control-sm" id="info1"  name="info1" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Info2</span>
                    <input type="text" class="form-control-sm" id="info2"  name="info2" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Info3</span>
                    <input type="text" class="form-control-sm" id="info3"  name="info3" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">info4</span>
                    <input type="text" class="form-control-sm" id="info4"  name="info4" value=""/>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">comments</span>
                    <input type="text" class="form-control-sm" id="comments"  name="comments" value=""/>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                        <input class="btn btn-secondary" type="submit" id="UpdateReferenceButton" value="Add/Update Reference"/>
                        <input type="hidden" name="QueryType" id="UpdateQueryType" value=""/>
                        <input type="hidden" name="action" value="UpdateReference"/>
                </div>
            </div>
            <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">longinfo1</span>
                    <input type="text" class="form-control" id="longinfo1"  name="longinfo1" value=""/>
                </div>
            </div>
            
            
            
        </div>
        </fieldset>
        </form>
    

        <div class="row justify-content-center py-2">
            <div class="col d-flex">
                <div class="table-responsive" id="ReferenceDiv">
                    <table class="table table-hover table-striped w-auto" id="ResultDataTable">
                        <thead class="table-info">
                            <tr>
                                <th>Id</th>
                                <th>Type</th>
                                <th>Val</th>
                                <th>Active</th>
                                <th>Info1</th>
                                <th>Info2</th>
                                <th>Info3</th>
                                <th>Info4</th>
                                <th>LongInfo1</th>
                                <th>Comments</th>
                                <th>Updated</th>
                                <th>Updated By</th>
                                <th></th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php 
                            foreach($referencelistresults as $reference)
                            {
                                echo '<tr>';
                                echo '<td>'.$reference['id'].'&nbsp;<a href="#" attr-id="'.$reference['id'].'" attr-type="'.$reference['type'].'" attr-val="'.$reference['val'].'" attr-info1="'.$reference['info1'].'" attr-info2="'.$reference['info2'].'" attr-info3="'.$reference['info3'].'" attr-info4="'.$reference['info4'].'" attr-active="'.$reference['active'].'" attr-longinfo1="'.$reference['longinfo1'].'" attr-comments="'.$reference['comments'].'" class="editrefclass"><i class="bi bi-pencil-square"></a></td>';
                                echo '<td>'.$reference['type'].'</td>';
                                echo '<td>'.$reference['val'].'</td>';
                                echo '<td>'.$reference['active'].'</td>';
                                echo '<td>'.$reference['info1'].'</td>';
                                echo '<td>'.$reference['info2'].'</td>';
                                echo '<td>'.$reference['info3'].'</td>';
                                echo '<td>'.$reference['info4'].'</td>';
                                echo '<td>'.$reference['longinfo1'].'</td>';
                                echo '<td>'.$reference['comments'].'</td>';
                                //Convert the dates into local time
                                $updated = '';
                                if($reference['updated'] != null)
                                {
                                    $updatedTS = new DateTime($reference['updated']);
                                    $updatedTS = $updatedTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                                    $updated = $updatedTS->format('Y-m-d H:i:s'); // Change to Sydney
                                }
                                echo '<td>'.$updated.'</td>';
                                echo '<td>'.$reference['updated_by'].'</td>';
                                echo '<td><form action="/Controllers/ReferenceController.php" method="post"><button type="submit" onclick="return confirm(\'Are you sure you want to delete this item?\');"><i class="bi bi-trash"></i></button><input type="hidden" name="id" value="'.$reference['id'].'"/><input type="hidden" name="action" value="DeleteReference"/></form></td>';
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                        
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
        <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
        <input type="hidden" id="activemenuid" value="navbar-administration"/> 
</main>


<?php 
  include_once('carsalesfooter.php');
?>
<script type="text/javascript">
    $(document).ready(function () {
    //Initialise the Data Table as responsive
        new DataTable('#ResultDataTable', {
            responsive: true,
            pageLength: 30,
            /* No ordering applied by DataTables during initialisation */
            order: []
        });
        /*  Function to trigger on the update Reference button */
        $('#UpdateReferenceButton').on('click',function() {
            var searchQueryType = $('#SearchQueryType').val();//Get the value of the search Query
            $('#UpdateQueryType').val(searchQueryType);//Set it in the hidden field of the Update form so that after update it will be used to filter the results
            $('#editform').submit();//Submit the Edit form
        });

        $('#ReferenceDiv').on('click','.editrefclass',function() {
            var id = $(this).attr('attr-id');
            var type = $(this).attr('attr-type');
            var val = $(this).attr('attr-val');
            var active = $(this).attr('attr-active');
            var info1 = $(this).attr('attr-info1');
            var info2 = $(this).attr('attr-info2');
            var info3 = $(this).attr('attr-info3');
            var info4 = $(this).attr('attr-info4');
            var longinfo1 = $(this).attr('attr-longinfo1');
            var comments = $(this).attr('attr-comments');
            
            $('#id').val(id);
            $('#id_display').val(id);
            $('#val').val(val);
            $('#type').val(type);
            $('#active').val(active);
            $('#info1').val(info1);
            $('#info2').val(info2);
            $('#info3').val(info3);
            $('#info4').val(info4);
            $('#longinfo1').val(longinfo1);
            $('#comments').val(comments);
        });

        $("#editform").submit(function (e) {
            $(":submit").attr('disabled','disabled');
        });
        $("#searchform").submit(function (e) {
            $(":submit").attr('disabled','disabled');
        });
    });
</script>
    
