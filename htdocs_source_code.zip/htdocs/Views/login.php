﻿<?php 
  include_once('../header.php');
  include_once('../Models/OrgModel.php');

  $login = '';
    if(isset($_GET['login'])){
        $login = $_GET['login'];
    }
    
    $orgname = '';
    if(isset($_GET['org'])){
        $orgname = $_GET['org'];
    }
    //Get all active Orgs
$orgModel = new OrgModel();
$orgList = $orgModel->GetAllActiveOrgs();
                                                    
?>
        <div class="container">
            <div class="row justify-content-center py-5">
                <div class="col-lg-6 offset-lg-1  bg-white shadow rounded">
                    <div class="row align-items-start">
                        <div class="offset-lg-3 col-md-6 py-3">
                            <div class="bg-white h-100 text-white text-center pt-5">
                                <img src="/assets/images/salesmanager-logo.png" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div>

                    <form action="/Controllers/LoginController.php" method="post" class="row g-4">
                        <div class="row py-3 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <div class="input-group">
                                    <span class="input-group-text">Username</span>
                                    <input type="text" name="login" class="form-control" required value="<?php echo $login; ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="row  py-3 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <div class="input-group">
                                    <span class="input-group-text">Password</span>
                                    <input type="password" name="password" class="form-control" required/>
                                </div>
                             </div>
                        </div>
                        <div class="row  py-3 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <div class="input-group">
                                    <span class="input-group-text">Organisation</span>
                                    <select class="form-select-sm" id="org" name="org" required>
                                        <!--  Add Empty Option -->
                                        <option value="" <?php echo ($orgname == '') ? 'selected="selected"' : '';?>></option>
                                        <?php 
                                        foreach($orgList as $org)
                                        {
                                        ?>
                                            <option value="<?php echo $org['org_name']; ?>" <?php echo ($org['org_name'] == $orgname) ? 'selected="selected"' : '';?>><?php echo $org['org_name']; ?></option>
                                        <?php 
                                        }
                                        ?>
                                        

                                    </select>
                                </div>
                             </div>
                        </div>
                        <div class="row  py-2 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <a href="/Views/forgotpassword" class="float-end text-primary">Forgot Password?</a>
                            </div>
                        </div>
                        <div class="row py-1 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-primary px-4 float-end mt-4">login</button>
                                <input type="hidden" name="redirect_url" value="<?php if(isset($_SESSION['redirect_url'])){echo $_SESSION['redirect_url'];} ?>"/>
                                <input type="hidden" name="action" value="Login"/>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
  
    <div class="container">
        <?php
                if(isset($_GET['error'])&&($_GET['error']!='')){
                echo '<div class="row justify-content-center py-2">';
                echo '<div class="col">';
                echo '<p class="bg-danger text-white p-2 text-center fs-5">';
                echo $_GET['error'];
                echo '</p>';
                echo '</div>';
                echo '</div>';
            }
            
            if(isset($_GET['success'])&&($_GET['success']!='')){
                echo '<div class="row justify-content-center py-2">';
                echo '<div class="col">';
                echo '<p class="bg-success text-white p-2 text-center fs-5">';
                echo $_GET['success'];
                echo '</p>';
                echo '</div>';
                echo '</div>';
            }
            
        ?>
    </div>


<?php 
  include_once('../footer.php');
?>
