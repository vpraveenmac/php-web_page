﻿<?php 
  include_once('../header.php');
  $login = '';
    if(isset($_GET['login'])){
        $login = $_GET['login'];
    } 
                                                    
?>
        <div class="container">
            <div class="row justify-content-center py-5">
                <div class="col-lg-6 offset-lg-1  bg-white shadow rounded">
                    <div class="row align-items-start">
                        <div class="offset-lg-3 col-md-6 py-3">
                            <div class="bg-white h-100 text-white text-center pt-5">
                                <img src="/assets/images/salesmanager-logo.png" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <form action="/Controllers/LoginController.php" method="post" class="row g-4">
                        <div class="row py-3 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <div class="input-group">
                                    <span class="input-group-text">Username</span>
                                    <input type="text" name="login" class="form-control" required value="<?php echo $login; ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="row  py-2 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <a href="/Views/login" class="float-end text-primary">Back to Login</a>
                            </div>
                        </div>
                        <div class="row py-2 align-items-start">
                            <div class="col-md-6 offset-md-3">
                                <button type="submit" class="btn btn-primary px-4 float-end mt-4">Send Reset Link</button>
                                <input type="hidden" name="redirect_url" value="<?php if(isset($_SESSION['redirect_url'])){echo $_SESSION['redirect_url'];} ?>"/>
                                <input type="hidden" name="action" value="SendResetLink"/>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
  
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php
                    if(isset($_GET['error'])){
                        echo '<p class="text-danger">';
                        echo $_GET['error'];
                        echo '</p>';
                    }
                    if(isset($_GET['success'])){
                        echo '<p class="text-success">';
                        echo $_GET['success'];
                        echo '</p>';
                    }
                    ?>
                <br/><br/>
            </div>

       </div>
    </div>


<?php 
  include_once('../footer.php');
?>
