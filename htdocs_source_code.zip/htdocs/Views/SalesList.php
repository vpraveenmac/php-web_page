﻿<?php 
include_once('carsalesheader.php');
include_once('../Models/CarSalesModel.php');
include_once('../Models/LOVModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
//Check Authorisation
if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
{
   //We are logged in so we can proceed
}
else
{
  echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
  exit();
}
//Org name
$orgName = $_SESSION["OrgName"];
//User Name
$loggedUser = $_SESSION["UserName"];
//Get the list of queries and set the one whose Info1 = Default as the default one else set 'Default' as Default.
$queryNameList = array();
$queryName = 'Default';
//Get the Carsales Query List
$lovmodel = new LOVModel();
$CarSalesQueryList = $lovmodel->getActiveLOVByTypeOrg('CarsalesQuery',$orgName);
//Push the name value pair to the query name list array
foreach($CarSalesQueryList as $item)
{
    array_push(
        $queryNameList,array('text'=>$item['val'],'val'=>$item['val'])
    );
    if($item['info1']=='Default')
    {
        $queryName = $item['val'];
    }
    
}

//Check if the Query Name is passed
if(isset($_POST['queryName']))
{
    $queryName = $_POST['queryName'];
}
//Check if the Filter Type is passed
$filterType = 'All';
if(isset($_POST['filterType']))
{
    $filterType = $_POST['filterType'];
}

//Check if the WorkSchedule Date was passed in
$workscheduledate = '';
if(isset($_POST['workScheduledDate']))
{
    $workscheduledate = $_POST['workScheduledDate'];
}

$carsaleslist = array();//Initialise array
$carsalesmodel = new CarSalesModel();



//get the Work Item List
$CarSalesWorkItemList = $lovmodel->getActiveLOVByTypeOrg('CarsalesWorkItem',$orgName);
//Push the name value pair to the query name list array
foreach($CarSalesWorkItemList as $item)
{
    $text = "WorkItem : ".$item['val'];
    $val = "WORKITEM:".$item['val'];
    array_push(
        $queryNameList,array('text'=>$text,'val'=>$val)
    );
}
//Sort the query name list
//array_multisort($queryNameList['text'],SORT_ASC, SORT_STRING,$queryNameList);
asort($queryNameList);


//If the work scheduled date was passed in , we will use that to query else we will use the Query name
if(!empty($workscheduledate))
{
    $carsaleslist = $carsalesmodel->GetActiveSalesByScheduledDate($workscheduledate,$orgName);
}
else
{
    //If the query Name starts with the word "WorkItem:" Then we need to treat it specially and use a different query
    if (str_starts_with($queryName,"WORKITEM:"))
    {
        $workItem = str_replace($queryName,"WORKITEM:", "");
        $carsaleslist = $carsalesmodel->GetSalesByWorkItemOrg($workItem,$orgName);
    }
    else
    {
        $queryListMatch = $lovmodel->getActiveLOVByTypeValueOrg('CarsalesQuery',$queryName,$orgName);
        if (count($queryListMatch) == 0)
        {
            $_SESSION['error'] = 'No Query found with Identifier: '.$queryName;
        }
        else
        {
            $SQLquery = $queryListMatch[0]['longinfo1'];
            $SQLquery = $SQLquery. " AND org_name='".$orgName."'";
            //If filter type is User then only show those belonging to the user
            if($filterType=="User")
            {
                $SQLquery = $SQLquery . " AND stock_owner='". $loggedUser . "'";
            }
            $carsaleslist = $carsalesmodel->GetSalesDetailByQuery($SQLquery);
        }
        
    }
}

/**** Get Current Day in Sydney Time */
date_default_timezone_set('Australia/Sydney');
$now = time();
$currentDateSydneyTime = date("Y-m-d");

?>
<main id="main">
    <div class="container-fluid">
    <?php
         if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="bg-danger text-white p-2 text-center fs-5">';
            echo $_SESSION['error'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
            $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
        }
        if(isset($_GET['success'])&&($_GET['success']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="text-white bg-success p-2 text-center fs-5">';
            echo $_GET['success'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        
        ?>

        
        <!-- ***************************************************** -->
        <!-- ***************** Query Data ********************* -->
        <!-- ***************************************************** -->
        <form action="/Views/SalesList" id="queryform" method="post">
        <fieldset class="border rounded-2 py-1">
        <div class="row justify-content-center py-2">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Show</span>
                    <select id="queryName" name="queryName" class="form-select-sm">
                        <?php  foreach($queryNameList as $query)
                        {
                            if($query['val'] == $queryName)
                            {
                                echo '<option value="'.$query['val'].'" selected="selected">'.$query['text']. '</option>';
                            }
                            else
                            {
                                echo '<option value="'.$query['val'].'">'.$query['text']. '</option>';
                            }
                        }
                        ?>
                    </select>
                    <select id="filterType" name="filterType" class="form-select-sm">
                        <option value="User" <?php if($filterType=='User'){echo 'selected="selected"';}?>>My Sales</option>
                        <option value="All"  <?php if($filterType=='All'){echo 'selected="selected"';}?>>All</option>                       
                    </select>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Work Scheduled</span>
                    <input type="date" class="form-control-sm" required name="workScheduledDate" value="<?php echo $workscheduledate;?>"/>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 col-12">
                <div class="input-group mb-2">
                    <input class="btn btn-secondary" type="submit" value="Query Schedule"/>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-2">
                    <input class="btn btn-secondary" type="button" id="CreateEntryButton" value="Create Entry"/>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-2">
                    <input class="btn btn-secondary" type="button" id="ExportToExcelButton" value="Export to Excel"/>
                </div>
            </div>
        </div>
        </fieldset>
        </form>

       

    </div>
     <!-- ***************************************************** -->
        <!-- ***************** Query Results  ********************* -->
        <!-- ***************************************************** -->
    <div class="row justify-content-center py-0">
            <div class="col">
                <div class="table-responsive" id="CarsalesDiv">
                    <table id="ResultTable" class="table table-hover table-striped">
                    <thead class="table-secondary">
                        <tr>
                            <th>Sales Id</th>
                            <th>Make</th>
                            <th>Model</th>
                            <th>Mfg. Year</th>
                            <th>Trans.</th>
                            <th>Specs.</th>
                            <th>Status</th>
                            <th>Trfed.</th>
                            <th>Scheduled</th>
                            <th>Rego</th>
                            <th>Rego<br />Expiry</th>
                            <th>Purchase<br /> Date</th>
                            <th>Profit/Loss</th>
                            <th>Location</th>
                            <th>Stock Owner</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $totalProfitLoss = 0;
                    foreach($carsaleslist as $sale)
                    {
                        $regodaysleft = 999;
                        //Update the total Profit /Loss Count
                        $profit = 0;
                        if(!empty($sale['profit']))
                        {
                            $profit = intval($sale['profit']);
                        }
                        $totalProfitLoss = $totalProfitLoss + $profit;

                        if(!empty($sale['rego_expiry']))
                        {
                            $regoexpiryDate = strtotime($sale['rego_expiry']);
                            $datediff = $regoexpiryDate - $now;
                            $regodaysleft= round($datediff / (60 * 60 * 24));
                        }
                        $workschduledaysleft = 999;
                        if(!empty($sale['work_scheduled_date']))
                        {
                            $workscheduledDate = strtotime($sale['work_scheduled_date']);
                            $datediff = $workscheduledDate - $now;
                            $workschduledaysleft = round($datediff / (60 * 60 * 24));
                        }

                        $editsalelink = '/Views/EditCarSale?SalesNo='.$sale['sales_no'];
                        $screenname = 'CarSale_'.$sale['sales_no'];
                                


                        echo '<tr class="datarow" attr-id="'.$sale['sales_no'].'">';
                        echo '<td>'.$sale['sales_no'].'</td>';
                        if(empty($sale['work_scheduled_date']))
                        {
                            echo '<td>'.$sale['car_make'].'</td>';
                        }
                        else if ($workschduledaysleft == 0)//Due Today
                        {
                            echo '<td class="table-danger">'.$sale['car_make'].'</td>';
                        }
                        else if ($workschduledaysleft == 1)//Due Tomorrow
                        {
                            echo '<td class="table-danger">'.$sale['car_make'].'</td>';
                        }
                        else if ($workschduledaysleft == 2)//Due in 2 days
                        {
                            echo '<td class="table-warning">'.$sale['car_make'].'</td>';
                        }
                        else if ($workschduledaysleft == 3)//Due in 3 days
                        {
                            echo '<td class="table-success">'.$sale['car_make'].'</td>';
                        }
                        else
                        {
                            echo '<td>'.$sale['car_make'].'</td>';
                        }
                        echo '<td>'.$sale['car_model'].'</td>';
                        echo '<td>'.$sale['car_year'].'</td>';
                        echo '<td>'.$sale['transmission'].'</td>';
                        echo '<td>'.$sale['specifications'].'</td>';
                        echo '<td>'.$sale['sale_status'].'</td>';
                        echo '<td>'.$sale['transferred'].'</td>';
                        //Work scheduled date
                        if(!empty($sale['work_scheduled_date']))
                        {
                            $dateTS = new DateTime($sale['work_scheduled_date']);
                            $dateTS = $dateTS->setTimeZone(new DateTimeZone('Australia/Sydney'));// Change to Sydney
                            $dateVarFormatted = $dateTS->format('Y-m-d'); 

                            echo '<td style="white-space: nowrap">'.$dateVarFormatted.'</td>';
                        }
                        else
                        {
                            echo '<td></td>';
                        }
                        echo '<td>'.$sale['car_rego'].'</td>';
                        //Rego Expiry
                        if(empty($sale['rego_expiry']))
                        {
                            echo '<td></td>';
                        }
                        else if($regodaysleft < 30)
                        {
                            $dateTS = new DateTime($sale['rego_expiry']);
                            $dateTS = $dateTS->setTimeZone(new DateTimeZone('Australia/Sydney'));// Change to Sydney
                            $dateVarFormatted = $dateTS->format('Y-m-d'); 

                            echo '<td style="white-space: nowrap" class="table-danger">'.$dateVarFormatted.'</td>';
                        }
                        else if($regodaysleft < 90)
                        {
                            $dateTS = new DateTime($sale['rego_expiry']);
                            $dateTS = $dateTS->setTimeZone(new DateTimeZone('Australia/Sydney'));// Change to Sydney
                            $dateVarFormatted = $dateTS->format('Y-m-d'); 

                            echo '<td style="white-space: nowrap" class="table-warning">'.$dateVarFormatted.'</td>';
                        }
                        else
                        {
                            $dateTS = new DateTime($sale['rego_expiry']);
                            $dateTS = $dateTS->setTimeZone(new DateTimeZone('Australia/Sydney'));// Change to Sydney
                            $dateVarFormatted = $dateTS->format('Y-m-d'); 

                            echo '<td style="white-space: nowrap">'.$dateVarFormatted.'</td>';

                        }
                        //Purchase date
                        if(!empty($sale['purchase_date']))
                        {
                            $dateTS = new DateTime($sale['purchase_date']);
                            $dateTS = $dateTS->setTimeZone(new DateTimeZone('Australia/Sydney'));// Change to Sydney
                            $dateVarFormatted = $dateTS->format('Y-m-d'); 

                            echo '<td style="white-space: nowrap">'.$dateVarFormatted.'</td>';
                        }
                        else
                        {
                            echo '<td></td>';
                        }
                        if($profit < 0)
                        {
                            echo '<td class="table-danger">'.$profit.'</td>';
                        }
                        else if($profit > 0)
                        {
                            echo '<td class="table-success">'.$profit.'</td>';
                        }
                        else{
                            echo '<td>'.$profit.'</td>';
                        }
                        echo '<td>'.$sale['stock_location'].'</td>';
                        echo '<td>'.$sale['stock_owner'].'</td>';
                        echo '</tr>';
                    }
                    ?>
            </tbody>
        </table>
        <?php
        if($totalProfitLoss > 0)
        {
            echo '<text class="display-6 text-success">Total Profit/Loss: $'.$totalProfitLoss. '</text>';
        }
        else
        {
            echo '<text class="display-6 text-danger">Total Profit/Loss: $'.$totalProfitLoss. '</text>';
        }
        ?>
        
    </div>
     <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
     <input type="hidden" id="activemenuid" value="navbar-memberarea"/> 
    <div style="visibility:hidden">
        <form id="ExportForm" action="/Controllers/CarSalesController.php" method="post">
            <input type="text" id="ExportHeader" name="ExportHeader" value="" />
            <input type="text" id="ExportContent" name="ExportContent" value=""/>
            <input type="text" name="action" value="ExportData" />
        </form>
        <form id="CreteEntryForm" action="/Views/EditCarSale" method="get" target="_blank">
            <input type="text" name="SalesNo" value="0" />
            <input type="text" name="success" value="Create Entry" />
        </form>

</div>   

</main>
<?php 
include_once('carsalesfooter.php');

?>

    <!-- <script src="/assets/js/custom/CarsaleScripts.js"></script> -->
    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });
        });
        //Query Name dropdown list change
        $('#queryName').change(function () {
                $('#queryform').submit();
            });
        //Filter Type dropdown list change
        $('#filterType').change(function () {
                $('#queryform').submit();
            });
        //Export button click
            $('#ExportToExcelButton').on("click", function () {
            exportFunction();
        });

        //Create button click
        $('#CreateEntryButton').on("click", function () {
            $('#CreteEntryForm').submit();
        });

          
        //Disable submit buttons on form submissions
        $("#queryform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });


            var exportFunction = function () {

            //Go through each of the table rows and build the header and the content strings
           // var tblContent = "<table border=\"1\">";
            var headerString = "";
            var contentString = "";
            $('#CarsalesDiv #ResultTable tr').each(function () {
                $cells = $(this).find("th");
                $cells.each(function () {
                    headerString += $(this).text() + "|";
                });
                $cells = $(this).find("td");
                $cells.each(function () {
                    contentString +=  $(this).text() + "|";
                });
                //Add a newline to the end of the content String
                contentString += "[CRLF]";
            });
            //tblContent += "</table>";
            $('#ExportHeader').val(headerString);
            $('#ExportContent').val(contentString);
            $('#ExportForm').submit();
            }

            $('.datarow td').on("click",function () {
                $salesno = $(this).parent().attr('attr-id');
                window.open('/Views/EditCarSale?SalesNo='+$salesno, 'carsale_'+$salesno); 
            });
    </script>

