<footer id="footer" class="mt-auto">
    <div class="container d-md-flex py-4">

        <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
            &copy; Copyright <strong><span>Online SalesManager</span></strong>. All Rights Reserved
        </div>
        
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/groups/nwsfra" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
        </div>
    </div>
</footer>
<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="/assets/js/jquery-3.6.0.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js"></script>
</main>
</body>