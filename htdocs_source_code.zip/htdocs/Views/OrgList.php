﻿<?php 
include_once('carsalesheader.php');
include_once('../Models/OrgModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
  
  //Check Authorisation
  if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]))
  {
     //We are logged in so we can proceed
  }
  else
  {
    echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
    exit();
  }
  //ONly SuperAdmin has access to this screen
if($_SESSION["AccessLevel"] != "SuperUser")
{
    echo "<script>parent.self.location='../index?error=Unauthorised attempt to view/edit data';</script>";
    exit();
}
//We will get the org List
  $orgModel = new OrgModel();
  $orglistresults  = $orgModel->GetAllOrgs();
  date_default_timezone_set('UTC');//Set date time to UTC

  //Check if the Edit OrgId is passed
  $edit_orgid = '0';
    if(isset($_GET['edit_orgid']))
    {
        $edit_orgid = $_GET['edit_orgid'];
    }
    $edit_orgname='';
    $edit_orgactive='';
  //Try to get org detail from the DB
    $editorgresults = $orgModel->GetOrgDetailById($edit_orgid);
    //If found then assign the variables
    if(count($editorgresults) > 0)
    {
        $edit_orgname = $editorgresults[0]['org_name'];
        $edit_orgactive = $editorgresults[0]['active'];
    }
?>
<main id="main">
    <div class="container">
    <a name="messageanchor"></a>
    <?php
     if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
        echo '<div class="row justify-content-center py-2">';
        echo '<div class="col">';
        echo '<p class="bg-danger text-white p-2 text-center fs-5">';
        echo $_SESSION['error'];
        echo '</p>';
        echo '</div>';
        echo '</div>';
        $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
    }
    if(isset($_GET['success'])&&($_GET['success']!='')){
        echo '<div class="row justify-content-center py-2">';
        echo '<div class="col">';
        echo '<p class="text-white bg-success p-2 text-center fs-5">';
        echo $_GET['success'];
        echo '</p>';
        echo '</div>';
        echo '</div>';
    }
    ?>

     <!-- ***************************************************** -->
        <!-- ***************** ADD / EDIT Org ********************* -->
        <!-- ***************************************************** -->
        
        <fieldset class="border rounded-2 p-2">
        <legend class="float-none w-auto px-0 py-3" >Add/Edit Org</legend>
        <form action="/Controllers/OrgController.php" id="editform" method="post">
        <div class="row justify-content-center py-0">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Id</span>
                    <input type="text" class="form-control-sm" disabled name="id" value="<?php echo $edit_orgid;?>"/>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Org Name</span>
                    <input type="text" class="form-control-sm" required name="org_name" value="<?php echo $edit_orgname;?>"/>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Active</span>
                    <select name="active" class="form-select-sm">
                        <option value="Y"<?php $edit_orgactive == 'Y' ? 'selected="selected"' : '';?>>Y</option>
                        <option value="N"<?php $edit_orgactive == 'N' ? 'selected="selected"' : '';?>>N</option>
                    </select>
                                            
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-2">
                    <input class="btn btn-secondary" type="submit" value="Add/Update"/>
                    <input type="hidden" name="action" value="UpsertOrg"/>
                    <input type="hidden" name="id" value="<?php echo $edit_orgid;?>"/>
                </div>
            </div>
        </div>
        </form>
        </fieldset>
        

     <!-- ***************************************************** -->
        <!-- ***************** Org List  ********************* -->
        <!-- ***************************************************** -->
        <div class="row justify-content-center py-0">
            <div class="col-12">
                <div class="table-responsive" id="OrgDiv">
                    <table class="table table-hover table-striped" id="ResultTable">
                        <thead class="table-info">
                            <tr>
                                <th>Id</th>
                                <th>Org Name</th>
                                <th>Active</th>
                                <th>Updated</th>
                                <th>Updated By</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php 
                            foreach($orglistresults as $org)
                            {
                                echo '<tr>';
                                echo '<td>'.$org['id'].'</td>';
                                echo '<td>'.$org['org_name'].'&nbsp;<a href="/Views/OrgList?edit_orgid='.$org['id'].'"><i class="bi bi-pencil-square"></i></a>'.'</td>';
                                echo '<td>'.$org['active'].'</td>';
                                //Convert the dates into local time
                                $updated = '';
                                if($org['updated'] != null)
                                {
                                    $updatedTS = new DateTime($org['updated']);
                                    $updatedTS = $updatedTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                                    $updated = $updatedTS->format('Y-m-d H:i:s'); // Change to Sydney
                                }
                                echo '<td>'.$updated.'</td>';
                                echo '<td>'.$org['updated_by'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" attr-org_name="'.$org['org_name'].'" class="deleteorgclass"><i class="bi bi-trash"></i></a></td>';
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                        
                    </table>
                    
                </div>
            </div>
        </div>


  
        <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
        <input type="hidden" id="activemenuid" value="navbar-administration"/> 
        <div style="visibility: hidden;">
            <form action="/Controllers/OrgController.php" id="deleteform" method="post">
                <input name="org_name" id="delete_org_name" value=""/>
                <input name="action" value="DeleteOrg"/>
            </form>                            

        </div>
    </div>
</main>
<?php 
include_once('carsalesfooter.php');
?>

    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });

            $('#OrgDiv').on('click','.deleteorgclass',function() {
            var orgname = $(this).attr('attr-org_name');
            var sConfirm = confirm('Do you really want to delete the Organisation :' + orgname + '?');
            if(sConfirm == false)return;
            $('#delete_org_name').val(orgname);
            $('#deleteform').submit();

            });
            //Disable submit buttons on form submissions
            $("#deleteform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });

            $("#editform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });
            
        });
    </script>

