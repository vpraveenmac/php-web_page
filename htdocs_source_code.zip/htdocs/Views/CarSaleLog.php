﻿<?php 
include_once('editcarsaleheader.php');
include_once('../Models/CarSalesLogModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
//Check Authorisation
if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
{
   //We are logged in so we can proceed
}
else
{
  echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
  exit();
}
//Org name
$orgName = $_SESSION["OrgName"];
//Check if the SalesNo was passed in
if(!isset($_GET['SalesNo']))
{
    echo '<h3 class="text-danger">SalesNo parameter was not passed in</h3>';
    exit();
}
$salesNo  = $_GET['SalesNo'];
$carsaleslogmodel = new CarSalesLogModel();
$carsalelogs = $carsaleslogmodel->GetSalesLogsBySalesNoOrg($salesNo,$orgName);//Get the sales logs

/**** Get Current Day in Sydney Time */
date_default_timezone_set('Australia/Sydney');
$now = time();
$currentDateSydneyTime = date("Y-m-d");

?>
<main id="main">
    <div class="container-fluid">
    <?php
         if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="bg-danger text-white p-2 text-center fs-5">';
            echo $_SESSION['error'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
            $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
        }
        if(isset($_GET['success'])&&($_GET['success']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="text-white bg-success p-2 text-center fs-5">';
            echo $_GET['success'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        
        ?>

        <!-- ***************************************************** -->
        <!-- ***************** CarSales Log Data ********************* -->
        <!-- ***************************************************** -->
        <div class="row justify-content-start py-2">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                <table class="table table-striped">
                    <thead>
                        <tr class="table-dark">
                            <td>Id</td>
                            <td>Created</td>
                            <td>Created By</td>
                            <td>Log</td>
                        </tr>
                    </thead>
                    <?php 
                    foreach($carsalelogs as $log)
                    {
                        $created = '';
                        if($log['created'] != null)
                        {
                            $createdTS = new DateTime($log['created']);
                            $createdTS = $createdTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                            $created = $createdTS->format('Y-m-d H:i:s'); // Change to Sydney
                        }
                        echo '<tr>';
                        echo '<td>'.$log['id'].'</td>';
                        echo '<td>'.$created.'</td>';
                        echo '<td>'.$log['created_by'].'</td>';
                        echo '<td>'.$log['log'].'</td>';
                    }
                    ?>
                    
                </table>
            </div>
        </div>
      
     <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
     <input type="hidden" id="activemenuid" value="navbar-log"/> 
     <!-- Hidden field to store the sales_no passed in -->
     <input type="hidden" id="sales_no" value="<?php echo $salesNo; ?>"/>

</main>
<?php 
include_once('carsalesfooter.php');

?>

    <script src="/assets/js/carsalescripts.js"></script> <!-- Script will set the navbar links -->
    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });
        });
        //Query Name dropdown list change
        $('#queryName').change(function () {
                $('#queryform').submit();
            });
        //Export button click
            $('#ExportToExcelButton').on("click", function () {
            exportFunction();
        });

          
        //Disable submit buttons on form submissions
        $("#queryform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });


            var exportFunction = function () {

            //Go through each of the table rows and build the header and the content strings
           // var tblContent = "<table border=\"1\">";
            var headerString = "";
            var contentString = "";
            $('#CarsalesDiv #ResultTable tr').each(function () {
                $cells = $(this).find("th");
                $cells.each(function () {
                    headerString += $(this).text() + "|";
                });
                $cells = $(this).find("td");
                $cells.each(function () {
                    contentString +=  $(this).text() + "|";
                });
                //Add a newline to the end of the content String
                contentString += "[CRLF]";
            });
            //tblContent += "</table>";
            $('#ExportHeader').val(headerString);
            $('#ExportContent').val(contentString);
            $('#ExportForm').submit();
            }

    </script>

