﻿<?php 
  include_once('../header.php');
 
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
  
  /*******************************************************************************************/
  /*******  User should be logged in to perform this function *************/
    /*******************************************************************************************/

  /* First check that the user is logged in and has the correct access level. If not we are going to send it back */
if(!isset($_SESSION["UserName"]))
{
    echo "<script>parent.self.location='../login?error=Please login to update password';</script>";
    exit();
}
$username = $_SESSION["UserName"];
                                                    
?>
        <div class="container">
            <div class="row justify-content-center py-5">
                <div class="col-lg-6 offset-lg-1  bg-white shadow rounded">
                    <div class="row align-items-start">
                        <div class="offset-lg-3 col-md-6 py-3">
                            <div class="bg-white h-100 text-white text-center pt-5">
                                <img src="/assets/images/salesmanager-logo.png" alt="" class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <form action="/Controllers/LoginController.php" method="post" id="updatepasswordform" class="row g-4">
                        <div class="row py-3 align-items-start">
                            <div class="col-md-7 offset-md-2">
                                <div class="input-group">
                                    <span class="input-group-text">Current Password</span>
                                    <input type="password" name="currentpassword" class="form-control" required />
                                </div>
                            </div>
                        </div>
                        <div class="row py-3 align-items-start">
                            <div class="col-md-7 offset-md-2">
                                <div class="input-group">
                                <span class="input-group-text">New Password</span>
                                    <input type="password" id="newpassword"  name="newpassword" class="form-control" required />
                                </div>
                            </div>
                        </div>
                        <div class="row py-3 align-items-start">
                            <div class="col-md-7 offset-md-2">
                                <div class="input-group">
                                <span class="input-group-text">Confirm New Password</span>
                                    <input type="password" id="newpassword2"  name="newpassword2" class="form-control" required />
                                </div>
                            </div>
                        </div>
                        <div class="row py-2 align-items-start">
                            <div class="col-md-7 offset-md-2">
                                <button type="submit" class="btn btn-primary px-4 float-end mt-4">Update Password</button>
                                <input type="hidden" name="username" value="<?php echo $username ?>" />
                                <input type="hidden" name="action" value="UpdatePassword"/>
                            </div>
                        </div>
                        <div class="row py-2 align-items-start">
                            <div class="col">
                                <ul>
                                    <li>Password must be at least 8 characters in length.</li>
                                    <li>Password must include uppercase and lowercase letters.</li>
                                    <li>Password must include at least one number.</li>
                                </ul>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
  
    <div class="container">
        <a name="messageanchor"></a>
        <?php
        if(isset($_GET['error'])&&($_GET['error']!='')){
            echo '<div class="row justify-content-center py-2">';
            echo '<div class="col">';
            echo '<p class="bg-danger text-white p-2 text-center fs-5">';
            echo $_GET['error'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        if(isset($_GET['success'])&&($_GET['success']!='')){
            echo '<div class="row justify-content-center py-2">';
            echo '<div class="col">';
            echo '<p class="text-white bg-success p-2 text-center fs-5">';
            echo $_GET['success'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
    <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
    <input type="hidden" id="activemenuid" value="navbar-memberarea"/> 


<?php 
  include_once('../footer.php');
?>
<script type="text/javascript">
  $(document).ready(function () {

    $("#updatepasswordform").submit(function (e) {
        var newpassword = $('#newpassword').val();
        var newpassword2 = $('#newpassword2').val();
        if(newpassword != newpassword2)
        {
            alert('Error: New Passwords do not match');
            return false;
        }

        $(":submit").attr('disabled','disabled');
    });
   
   
   
});
</script>
