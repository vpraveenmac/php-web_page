<?php 
include_once('editcarsaleheader.php');
include_once('../Models/CarSalesModel.php');
include_once('../Models/CarSalesExpenseModel.php');
include_once('../Models/CarSalesNoteModel.php');
include_once('../Models/LOVModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
//Check Authorisation
if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
{
   //We are logged in so we can proceed
}
else
{
  echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
  exit();
}
//Org name
$orgName = $_SESSION["OrgName"];
//Check if the SalesNo was passed in
if(!isset($_GET['SalesNo']))
{
    echo '<h3 class="text-danger">SalesNo parameter was not passed in</h3>';
    exit();
}
$salesNo  = $_GET['SalesNo'];
/*********** Get the main sales data ************/
$carsalesmodel = new CarSalesModel();
$carsaleData = $carsalesmodel->GetSalesDetailBySalesNoOrg($salesNo,$orgName);//Get the sales data
//Check if the Sales was found
/* if(count($carsaleData) == 0)
{
    echo '<h3 class="text-danger">No data with SalesNo='.$salesNo.' was found in the organisation</h3>';
    exit();
} */
/*********** Get the data from the expenses table  ************/
$carsalesexpensemodel = new CarSalesExpenseModel();
$carsaleExpenseData = $carsalesexpensemodel->GetSalesExpensesBySalesNoOrg($salesNo,$orgName);//Get the sales data

/************* Get the last 5 notes for the Sales ***********/
$carsalesNotemodel = new CarSalesNoteModel();
$carsaleNotes = $carsalesNotemodel->GetSalesNotesBySalesNoOrgLimit5($salesNo,$orgName);

$lovmodel = new LOVModel();
//Create the UI Model
$UIModel = $lovmodel->CreateCarsalesModelUI($orgName);

/**** Get Current Day in Sydney Time */
date_default_timezone_set('Australia/Sydney');
$now = time();
$currentDateSydneyTime = date("Y-m-d");
/************ Create an array of worklist items *******************/
$worklistItemChecklistArray = array();
$currentworklistitemsArray = array();
if(count($carsaleData) > 0)
{
$currentworklistitems = $carsaleData[0]['workitem_list'];
$currentworklistitemsArray = explode('|',$currentworklistitems);
}
?>
<main id="main">
    <div class="container-fluid">
    <?php
         if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="bg-danger text-white p-2 text-center fs-5">';
            echo $_SESSION['error'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
            $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
        }
        if(isset($_GET['success'])&&($_GET['success']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="text-white bg-success p-2 text-center fs-5">';
            echo $_GET['success'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        
        ?>

        
        <!-- ***************************************************** -->
        <!-- ***************** CarSales Data Data ********************* -->
        <!-- ***************************************************** -->
        <form action="/Controllers/CarSalesController.php" id="editform" autocomplete="off" method="post">
        <div class="row justify-content-start py-3">
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                <div class="row justify-content-start">
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Sales No:</span>
                            <input type="text" class="form-control-sm  col-sm-3" disabled value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['sales_no'];}?>"/>
                            <input type="hidden" name="sales_no" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['sales_no'];}else {echo '0';}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Status:</span>
                            <select name="sale_status" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->StatusCodes as $statusCode)
                                {
                                    if($statusCode['val'] == $carsaleData[0]['sale_status'])
                                    {
                                        echo '<option value="'.$statusCode['val'].'" selected="selected">'. $statusCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$statusCode['val'].'">' .$statusCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['sale_status'].'" selected="selected">'. $carsaleData[0]['sale_status']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Make:</span>
                            <select name="car_make" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->CarMakeCodes as $makeCode)
                                {
                                    if($makeCode['val'] == $carsaleData[0]['car_make'])
                                    {
                                        echo '<option value="'.$makeCode['val'].'" selected="selected">'. $makeCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$makeCode['val'].'">' .$makeCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['car_make'].'" selected="selected">'. $carsaleData[0]['car_make']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Model:</span>
                            <input type="text" name="car_model" class="form-control-sm" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['car_model'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Color:</span>
                            <input type="text" name="car_color" class="form-control-sm  col-sm-3" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['car_color'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Transmission:</span>
                            <select name="transmission" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->TransmissionCodes as $transmissionCode)
                                {
                                    if($transmissionCode['val'] == $carsaleData[0]['transmission'])
                                    {
                                        echo '<option value="'.$transmissionCode['val'].'" selected="selected">'. $transmissionCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$transmissionCode['val'].'">' .$transmissionCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['transmission'].'" selected="selected">'. $carsaleData[0]['transmission']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Fuel Type:</span>
                            <select name="fuel_type" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->FuelTypeCodes as $fuelTypeCode)
                                {
                                    if($fuelTypeCode['val'] == $carsaleData[0]['fuel_type'])
                                    {
                                        echo '<option value="'.$fuelTypeCode['val'].'" selected="selected">'. $fuelTypeCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$fuelTypeCode['val'].'">' .$fuelTypeCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['fuel_type'].'" selected="selected">'. $carsaleData[0]['fuel_type']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Mileage:</span>
                            <input type="number" name="mileage" class="form-control-sm  col-sm-3" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['mileage'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Mfg. Year:</span>
                            <input type="number" name="car_year" class="form-control-sm  col-sm-3" pattern="\d{4}" maxlength="4" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['car_year'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Car Rego:</span>
                            <input type="text" name="car_rego" class="form-control-sm  col-sm-3"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['car_rego'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Rego Expiry:</span>
                            <input type="date" name="rego_expiry" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['rego_expiry'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Specifications:</span>
                            <input type="text" name="specifications" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['specifications'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Damage:</span>
                            <input type="text" name="damage" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['damage'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">ADED:</span>
                            <input type="number" name="ADED" class="form-control-sm  col-sm-3"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['ADED'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Purchase Date:</span>
                            <input type="date" name="purchase_date" id="purchase_date" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['purchase_date'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Purchase Price:</span>
                            <input type="number" step="0.01" name="purchase_price" id="purchase_price" class="form-control-sm  col-sm-3" pattern='[0-9]+(\\.[0-9][0-9]?)?' value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['purchase_price'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Advertised Date:</span>
                            <input type="date" name="date_advertised" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['date_advertised'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Sold Date:</span>
                            <input type="date" name="sold_date" id="sold_date" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['sold_date'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Sold Price:</span>
                            <input type="number" step="0.01" name="sold_price" id="sold_price" class="form-control-sm  col-sm-3" pattern='[0-9]+(\\.[0-9][0-9]?)?' value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['sold_price'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <?php
                            if(count($carsaleData) == 0){
                                echo '<span class="input-group-text">Profit:</span>';
                            }
                            else if($carsaleData[0]['profit']!=null && $carsaleData[0]['profit'] !='' && $carsaleData[0]['profit'] > 0)
                            {
                                echo '<span class="input-group-text bg-success">Profit:</span>';
                            }
                            else if($carsaleData[0]['profit']!=null && $carsaleData[0]['profit'] !='' && $carsaleData[0]['profit'] < 0)
                            {
                                echo '<span class="input-group-text bg-danger">Profit:</span>';
                            }
                            else
                            {
                                echo '<span class="input-group-text">Profit:</span>';
                            }
                            ?>
                            <input type="number" step="0.01" class="form-control-sm  col-sm-3" disabled value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['profit'];}?>"/>
                            <input type="hidden" name="profit" value="<?php echo $carsaleData[0]['profit'];?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-info">GST:</span>
                            <input type="number" step="0.01" class="form-control-sm  col-sm-3" disabled value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['gst'];}?>"/>
                            <input type="hidden" name="gst" value="<?php echo $carsaleData[0]['gst'];?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Location:</span>
                            <select name="stock_location" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->StockLocationCodes as $stockLocationCode)
                                {
                                    if($stockLocationCode['val'] == $carsaleData[0]['stock_location'])
                                    {
                                        echo '<option value="'.$stockLocationCode['val'].'" selected="selected">'. $stockLocationCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$stockLocationCode['val'].'">' .$stockLocationCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['stock_location'].'" selected="selected">'. $carsaleData[0]['stock_location']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Transferred:</span>
                            <select name="transferred" class="form-select-sm">
                                <?php 
                                $foundval = false;
                                foreach($UIModel->TransferredCodes as $transferredCode)
                                {
                                    if($transferredCode['val'] == $carsaleData[0]['transferred'])
                                    {
                                        echo '<option value="'.$transferredCode['val'].'" selected="selected">'. $transferredCode['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$transferredCode['val'].'">' .$transferredCode['text']. '</option>';

                                    }
                                    
                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['transferred'].'" selected="selected">'. $carsaleData[0]['transferred']. '</option>';
                                }

                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">SalesPerson:</span>
                            <select name="sales_person" class="form-select-sm">
                                <?php 
                                 $foundval = false;
                                foreach($UIModel->SalesPersonCodes as $salesperson)
                                {
                                    if($salesperson == $carsaleData[0]['sales_person'])
                                    {
                                        echo '<option value="'.$salesperson['val'].'" selected="selected">' . $salesperson['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$salesperson['val'].'">' . $salesperson['text']. '</option>';

                                    }

                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['sales_person'].'" selected="selected">'. $carsaleData[0]['sales_person']. '</option>';
                                }
                                
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Stock Owner:</span>
                            <select name="stock_owner" class="form-select-sm">
                                <?php 
                                 $foundval = false;
                                foreach($UIModel->SalesPersonCodes as $stockowner)//Stockowner is a User as well
                                {
                                    if($stockowner == $carsaleData[0]['stock_owner'])
                                    {
                                        echo '<option value="'.$stockowner['val'].'" selected="selected">' . $stockowner['text']. '</option>';
                                        $foundval = true;
                                    }
                                    else
                                    {
                                        echo '<option value="'.$stockowner['val'].'">' . $stockowner['text']. '</option>';

                                    }

                                } 
                                /* If the value is not part of the list then add a drop down with that value */
                                if($foundval == false){
                                    echo '<option value="'.$carsaleData[0]['stock_owner'].'" selected="selected">'. $carsaleData[0]['stock_owner']. '</option>';
                                }
                                
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                <div class="row justify-content-start">
                    <div class="col-12 d-flex">
                        <div class="table-responsive">
                            <table class="table table-striped" id="ExpenseTable">
                                <thead>
                                    <tr class="table-danger">
                                        <td>Expense Type</td>
                                        <td>Amount($)</td>
                                        <td>Expensed By</td>
                                    </tr>
                                </thead>
                            <?php foreach($carsaleExpenseData as $expense){?>
                            <tr title="<?php echo 'Created:'.$expense['created'].' by '.$expense['created_by']; ?>">
                                <td><a href="#" id="<?php echo $expense['id']; ?>" class="deleteexpenseclass"><i class="bi bi-trash"></i></a> &nbsp;  &nbsp; <?php echo $expense['expense_type']; ?></td>
                                <td><?php echo $expense['expense_value']; ?></td>
                                <td><?php echo $expense['expense_by']; ?></td>
                            </tr>
                            <?php } ?>
                            </table>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-info">Total Cost and Expenses:</span>
                            <input type="number" step="0.01" class="form-control-sm  col-sm-3" disabled value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['total_expenses'];}?>"/>
                            <input type="hidden" name="total_expenses" value="<?php echo $carsaleData[0]['gst'];?>"/>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                <div class="row justify-content-start">
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Work Scheduled:</span>
                            <input type="date" name="work_scheduled_date" class="form-control-sm"  value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['work_scheduled_date'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <b>Work List:</b>
                        <?php
                        

                        /*** Go through the list of worklist item codes and write them as checked/unchecked checkboxes
                         * We will use the same input name which will be in an array form ****/
                        foreach($UIModel->WorkItemCodes as $worklistitem)
                        {
                            if(empty($worklistitem)||trim($worklistitem)=='')continue;
                            if(in_array($worklistitem, $currentworklistitemsArray))
                            {
                                //value was found so add as a checked item
                                echo '<div class="form-check">';
                                echo '<input class="form-check-input" type="checkbox" checked name="WorkItem[]" value="'.trim($worklistitem).'">';
                                echo '<label class="form-check-label">'. trim($worklistitem).'</label>';
                                echo '</div>';
                            } 
                            else{
                                //value was not found so add as unchecked item
                                echo '<div class="form-check">';
                                echo '<input class="form-check-input" type="checkbox" name="WorkItem[]" value="'.trim($worklistitem).'">';
                                echo '<label class="form-check-label">'. trim($worklistitem).'</label>';
                                echo '</div>';
                            }
                        }
                        /*** We might have worklist items on the sales record which is no longer part of the worklist item codes. 
                         * We will write them as checked ****/
                        foreach($currentworklistitemsArray as $currentworklist)
                        {
                            if(empty($currentworklist)||(trim($currentworklist)==''))continue;
                            if(in_array($currentworklist, $UIModel->WorkItemCodes))
                            {
                                //value was found so do nothing as it would have been taken care of in the earlier loop
                                
                            } 
                            else{
                                //Value was not found so it is not part of teh worklist item codes. we will need to write it as a checked item
                                echo '<div class="form-check">';
                                echo '<input class="form-check-input" type="checkbox" checked  value="'.trim($currentworklist).'">';
                                echo '<label class="form-check-label">'. trim($currentworklist).'</label>';
                                echo '</div>';
                            }

                        }

                        
                        ?>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Created: <?php if(count($carsaleData) > 0){echo $carsaleData[0]['created']. ' by '.$carsaleData[0]['created_by'];}?></span>
                            <input type="hidden" name="created" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['created'];}?>"/>
                            <input type="hidden" name="created_by" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['created_by'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text">Updated: <?php if(count($carsaleData) > 0){echo $carsaleData[0]['updated']. ' by '.$carsaleData[0]['updated_by'];}?></span>
                            <input type="hidden" name="updated" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['updated'];}?>"/>
                            <input type="hidden" name="updated_by" value="<?php if(count($carsaleData) > 0){echo $carsaleData[0]['updated_by'];}?>"/>
                        </div>
                    </div>
                    <div class="col-12"><hr/></div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-warning">Add Expense:</span>
                            <select name="add_expense_type" class="form-select-sm">
                            <?php 
                                foreach($UIModel->ExpenseTypeCodes as $expenseCode)
                                {
                                    echo '<option value="'.$expenseCode['val'].'" selected="selected">'. $expenseCode['text']. '</option>';
                                } 
                            ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-warning">Expense Amount:</span>
                            <input type="number" step="0.01" class="form-control-sm col-sm-3" name="add_expense_value"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-warning">Expensed By:</span>
                            <input type="text" class="form-control-sm col-sm-2" name="add_expense_by"/>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-warning">Add Note:</span>
                            <textarea name="add_note" class="form-control-sm"></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="input-group mb-2">
                            <input class="btn btn-secondary" type="submit" value="Save Changes"/>
                            <input type="hidden" name="action" value="UpsertData">
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        </form>
        <div class="row justify-content-start py-2">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                <table class="table table-striped">
                    <thead>
                        <tr class="table-dark">
                            <td>Id</td>
                            <td>Created</td>
                            <td>Created By</td>
                            <td>Notes</td>
                        </tr>
                    </thead>
                    <?php 
                    foreach($carsaleNotes as $note)
                    {
                        $created = '';
                        if($note['created'] != null)
                        {
                            $createdTS = new DateTime($note['created']);
                            $createdTS = $createdTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                            $created = $createdTS->format('Y-m-d H:i:s'); // Change to Sydney
                        }
                        echo '<tr>';
                        echo '<td>'.$note['id'].'</td>';
                        echo '<td>'.$created.'</td>';
                        echo '<td>'.$note['created_by'].'</td>';
                        echo '<td>'.$note['note'].'</td>';
                    }
                    ?>
                    
                </table>
            </div>
        </div>
     <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
     <input type="hidden" id="activemenuid" value="navbar-info"/> 
     <!-- Hidden field to store the sales_no passed in -->
     <input type="hidden" id="sales_no" value="<?php echo $salesNo; ?>"/>
    <div style="visibility:hidden">
        <form id="ExportForm" action="/Controllers/CarSalesController.php" method="post">
            <input type="text" id="ExportHeader" name="ExportHeader" value="" />
            <input type="text" id="ExportContent" name="ExportContent" value=""/>
            <input type="text" name="action" value="ExportData" />
        </form>
        <form id="DeleteExpenseForm" action="/Controllers/CarSalesController.php" method="post">
            <input type="hidden" name="action" value="DeleteExpense"/>
            <input type="hidden" id="delete_expense_sales_no" name="sales_no"/>
            <input type="hidden" id="delete_expense_id" name="expense_id"/>
        </form>

</div>   

</main>
<?php 
include_once('carsalesfooter.php');

?>

    <script src="/assets/js/carsalescripts.js"></script> <!-- Script will set the navbar links -->
    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });
             /*********** Delete Expense Function ***************** */
             $('#ExpenseTable').on('click','.deleteexpenseclass',function() {
                var expenseid = $(this).attr('id');//get the id
                var salesno = $('#sales_no').val();
                var sConfirm = confirm('Delete Expense?');
                if(sConfirm == false)return false;
                //Populate the form fields
                $('#delete_expense_sales_no').prop('value',salesno);
                $('#delete_expense_id').prop('value',expenseid);
                $('#DeleteExpenseForm').submit();//Submit the form

            });

        //Disable submit buttons on form submissions
        $("#editform").submit(function (e) {
            var sold_date = $('#sold_date').val();
            var sold_price = $('#sold_price').val();
            var purhcase_date = $('#purchase_date').val();
            var purchase_price = $('#purchase_price').val();
            if((sold_date !='' && sold_price == '')||(sold_date =='' && sold_price != ''))
            {
                alert('Validation Error: Sold Date and Sole Price must be both entered or kept empty');
                return false;
            }
            if((purhcase_date !='' && purchase_price == '')||(purhcase_date =='' && purchase_price != ''))
            {
                alert('Validation Error: Purchased Date and Purchased Price must be both entered or kept empty');
                return false;
            }

            $(":submit").attr('disabled','disabled');
        });

        });
       

           
    </script>

