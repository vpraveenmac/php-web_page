﻿<?php 
include_once('editcarsaleheader.php');
include_once('../Models/CarSalesFileModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
//Check Authorisation
if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
{
   //We are logged in so we can proceed
}
else
{
  echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
  exit();
}
//Org name
$orgName = $_SESSION["OrgName"];
//Check if the SalesNo was passed in
if(!isset($_GET['SalesNo']))
{
    echo '<h3 class="text-danger">SalesNo parameter was not passed in</h3>';
    exit();
}
$salesNo  = $_GET['SalesNo'];
$carsalesfilemodel = new CarSalesFileModel();
$carsalefiles = $carsalesfilemodel->GetSalesFilesBySalesNoOrg($salesNo,$orgName);//Get the sales files

/**** Get Current Day in Sydney Time */
date_default_timezone_set('Australia/Sydney');
$now = time();
$currentDateSydneyTime = date("Y-m-d");

?>
<main id="main">
    <div class="container-fluid">
    <?php
         if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="bg-danger text-white p-2 text-center fs-5">';
            echo $_SESSION['error'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
            $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
        }
        if(isset($_GET['success'])&&($_GET['success']!='')){
            echo '<div class="row justify-content-center">';
            echo '<div class="col">';
            echo '<p class="text-white bg-success p-2 text-center fs-5">';
            echo $_GET['success'];
            echo '</p>';
            echo '</div>';
            echo '</div>';
        }
        
        ?>

         <!-- ***************************************************** -->
        <!-- ***************** UPLOAD File  ********************* -->
        <!-- ***************************************************** -->

        <form action="/Controllers/CarsalesFileController.php" id="uploadfileform" enctype="multipart/form-data" method="post">
        <!-- <legend class="float-none w-auto px-0 py-3" >Upload File</legend> -->
        <div class="row justify-content-start py-2">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-12">
                <input class="form-control" type="file" required name="formFile">
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-12">
                <input class="btn btn-secondary" type="submit" value="Upload File"/>
                <input type="hidden" name="action" value="UploadFile"/>
                <input type="hidden" name="sales_no" value="<?php echo $salesNo;?>"/>
            </div>
        </div>
        </form>
                   

        <!-- ***************************************************** -->
        <!-- ***************** CarSales Files Data ********************* -->
        <!-- ***************************************************** -->
        <div class="row justify-content-start py-2">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                <table class="table table-striped">
                    <thead>
                        <tr class="table-dark">
                            <td>Id</td>
                            <td>Description</td>
                            <td>Thumbnail</td>
                            <td>Created</td>
                            <td>Created By</td>
                            <td></td>
                        </tr>
                    </thead>
                    <?php 
                    foreach($carsalefiles as $file)
                    {
                        $created = '';
                        if($file['created'] != null)
                        {
                            $createdTS = new DateTime($file['created']);
                            $createdTS = $createdTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                            $created = $createdTS->format('Y-m-d H:i:s'); // Change to Sydney
                        }
                        echo '<tr>';
                        echo '<td>'.$file['id'].'</td>';
                        echo '<td>';
                        echo '<div id="filename_show_'.$file['id'].'" style="display: block;">';
                        echo '<span id="filename_description_'.$file['id'].'">'.$file['description'].'</span>&nbsp;<a class="editfiledescriptionclass" href="#" id="'.$file['id'].'"><i class="bi bi-pencil-square"></i></a>';
                        echo '</div>';
                        echo '<div id="filename_edit_'.$file['id'].'" style="display: none;">';
                        echo '<input type="text" id="description_'.$file['id'].'" class="form-control-sm" value="'.$file['description'].'"/>';
                        echo '&nbsp;<a class="savefiledescriptionclass" href="#"  id="'.$file['id'].'"><i class="bi bi-check-circle"></i></a>';
                        echo '&nbsp;<a class="canceleditfiledescriptionclass" href="#" id="'.$file['id'].'"><i class="bi bi-x"></i></a>';
                        echo '</div>';
                        echo '</td>';
                        echo '<td>';
                        if (str_contains($file['mime_type'],'image'))
                        {

                            echo '<img alt="Image" width="355" height="200" src="data:'.$file['mime_type'].';base64,'.base64_encode($file['data']).'" />';
                        }
                        echo '</td>';
                        echo '<td>'.$created.'</td>';
                        echo '<td>'.$file['created_by'].'</td>';
                        echo '<td><a href="#" id="'.$file['id'].'" class="deletefileclass"><i class="bi bi-trash"></i></a></td>';
                        echo '</tr>';
                    }
                    ?>
                    
                </table>
            </div>
        </div>
      
     <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
     <input type="hidden" id="activemenuid" value="navbar-file"/> 
      <!-- Hidden field to store the sales_no passed in -->
     <input type="hidden" id="sales_no" value="<?php echo $salesNo; ?>"/>      
     <div style="visibility:hidden;">
        <form action="/Controllers/CarSalesFileController.php" method="post" id="deletefileform">
            <input type="hidden" name="action" value="DeleteFile"/>
            <input type="hidden" id="delete_file_sales_no" name="sales_no"/>
            <input type="hidden" id="delete_file_id" name="file_id"/>
        </form>
    </div>
</main>
<?php 
include_once('carsalesfooter.php');

?>

    <script src="/assets/js/carsalescripts.js"></script> <!-- Script will set the navbar links -->
    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });
        });
        //Edit Icon Click. Show the Edit DIV and hide the show div
        $('.editfiledescriptionclass').on("click", function () {
            var fileid = $(this).attr('id');//get the id
            $('#' + 'filename_show_'+fileid).hide();//Hide the Show DIV
            $('#' + 'filename_edit_'+fileid).show();//Show the Edit DIV

        });
        
        //Cancel Icon Click. Hide the Edit DIV and Show the show div
        $('.canceleditfiledescriptionclass').on("click", function () {
            var fileid = $(this).attr('id');//get the id
            $('#' + 'filename_show_'+fileid).show();//Show the Show DIV
            $('#' + 'filename_edit_'+fileid).hide();//Hide the Edit DIV

            var oldDescription = $('#' + 'filename_description_' + fileid).html();//get current description
            $('#' + 'description_'+fileid).val(oldDescription);//reset the value of text field

        });

         //Save Icon Click. 
         $('.savefiledescriptionclass').on("click", function () {
                var fileid = $(this).attr('id');//get the id
                var salesNo = $('#sales_no').val();
                var description = $('#' + 'description_'+fileid).val();//get the value of modified text
                if(description==''){
                    alert('Error: Description cannot be empty');
                    return false;
                }
                //Now we can send the AJAX request to update the file description
                $.ajax({
                url: "/Controllers/CarSalesFileController.php",
                type: "POST",
                data: "action=UpdateFileDescription&sales_no="+ salesNo + "&file_id=" + fileid + "&description=" + description
                })
                .done(function (ajaxResult) {
                    $('#' + 'filename_description_' + fileid).html(description);//Update the Display Field with new value
               
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                });
                $('#' + 'filename_show_'+fileid).show();//Show the Show DIV
                $('#' + 'filename_edit_'+fileid).hide();//Hide the Edit DIV

            });

         
         //Delete Icon Click.
         $('.deletefileclass').on("click", function () {
                var fileid = $(this).attr('id');//get the id
                var salesno = $('#sales_no').val();
                var sConfirm = confirm('Delete File?');
                if(sConfirm == false)return false;
                //Populate the form fields
                $('#delete_file_sales_no').prop('value',salesno);
                $('#delete_file_id').prop('value',fileid);
                $('#deletefileform').submit();//Submit the form

            });

        //Export button click
        $('#ExportToExcelButton').on("click", function () {
            exportFunction();
        });

          
        //Disable submit buttons on form submissions
        $("#queryform").submit(function (e) {
            $(":submit").attr('disabled','disabled');
        });
        $("#deletefileform").submit(function (e) {
            $(":submit").attr('disabled','disabled');
        });

            var exportFunction = function () {

            //Go through each of the table rows and build the header and the content strings
           // var tblContent = "<table border=\"1\">";
            var headerString = "";
            var contentString = "";
            $('#CarsalesDiv #ResultTable tr').each(function () {
                $cells = $(this).find("th");
                $cells.each(function () {
                    headerString += $(this).text() + "|";
                });
                $cells = $(this).find("td");
                $cells.each(function () {
                    contentString +=  $(this).text() + "|";
                });
                //Add a newline to the end of the content String
                contentString += "[CRLF]";
            });
            //tblContent += "</table>";
            $('#ExportHeader').val(headerString);
            $('#ExportContent').val(contentString);
            $('#ExportForm').submit();
            }

    </script>

