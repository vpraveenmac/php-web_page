﻿<footer id="footer"  class="mt-auto">
<div class="container d-md-flex py-4">

<div class="me-md-auto text-center text-md-start">
  <div class="copyright">
    &copy; Copyright <strong><span>Online Sales Manager</span></strong>. All Rights Reserved
  </div>
  
</div>
<div class="social-links text-center text-md-right pt-3 pt-md-0">
  <a href="https://www.facebook.com/groups/nwsfra" target="_blank"><i class="bi bi-facebook"></i></a>
</div>
</div>
</footer>
<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Datatable Files -->
<script src="/assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="/assets/vendor/datatables/js/dataTables.bootstrap5.min.js"></script>
<script src="/assets/vendor/datatables/js/dataTables.responsive.min.js"></script>
<script src="/assets/vendor/datatables/js/responsive.bootstrap5.min.js"></script>

  <!-- Template Main JS File -->
  <script src="/assets/js/main.js"></script>
  <script src="/assets/js/carsalesmainscripts.js"></script>

</body>