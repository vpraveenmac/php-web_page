 <!-- Navbar Start -->
 <nav id="navbar" class="navbar">
      <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      <!-- <button class="mobile-nav-toggle" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      
        <ul class="nav menu">
          <li><a id="navbar-info" class="nav-link scrollto" href="/Views/EditCarSale?SalesNo=">Info</a></li>
          <li><a id="navbar-log" class="nav-link scrollto" href="/Views/CarSaleLog?SalesNo=">Logs</a></li>
          <li><a id="navbar-note" class="nav-link scrollto" href="/Views/CarSaleNote?SalesNo=">Notes</a></li>
          <li><a id="navbar-file" class="nav-link scrollto" href="/Views/CarSaleFile?SalesNo=">Files</a></li>
          <li><a id="delete-menu" href="#" onclick="if(!confirm('Delete Entry')){return false;}else{$('#deleteform').submit();}" class="nav-item scrollto"><i class="bi bi-trash fs-5"></i></a></li>
          <li><a href="#" class="nav-item nav-link" onclick="window.close();"><i class="bi bi-x-octagon fs-5"></i></a></li>
          <li><a id="navbar-home" class="nav-link scrollto" href="/Views/SalesList" target="saleslist">Back to List</a></li>
     </ul>
     <i class="bi bi-list mobile-nav-toggle"></i>
      
  </nav>

  <!-- Navbar End -->
  <div style="visibility: hidden;">
    <form action="/Controllers/CarSalesController.php" id="deleteform" method="post">
    <input type="hidden" id="delete_sales_no" name="sales_no" value="">
      <input type="hidden" name="action" value="DeleteData">
    </form>
  </div>

    