﻿<?php 
include_once('carsalesheader.php');
include_once('../Models/UserModel.php');
include_once('../Models/OrgModel.php');
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];//Session variable to use for Redirecting if the user needs to ReLogin
  
  //Check Authorisation
  if(isset($_SESSION["UserName"])&& isset($_SESSION["AccessLevel"]) && isset($_SESSION["OrgName"]))
  {
     //We are logged in so we can proceed
  }
  else
  {
    echo "<script>parent.self.location='../login?error=Please login to view data#messageanchor';</script>";
    exit();
  }
  //ONly SuperAdmin has access to this screen
if(($_SESSION["AccessLevel"] != "SuperUser")&&($_SESSION["AccessLevel"] != "OrgAdmin"))
{
    echo "<script>parent.self.location='../index?error=Unauthorised attempt to view/edit data';</script>";
    exit();
}
//We will get the user list. We will only show the uses in the current organisation
$orgName = '';
if(isset($_POST['SearchOrgName']))
{
    $orgName=$_POST['SearchOrgName'];
}

  $userModel = new UserModel();
  $userlist  = $userModel->GetAllUsersByOrg($orgName);

  date_default_timezone_set('UTC');//Set date time to UTC

  //Check if the Edit UserId is passed
  $edit_userid = '0';
    if(isset($_POST['edit_userid']))
    {
        $edit_userid = $_POST['edit_userid'];
    }
    $edit_userame='';
    $edit_useractive='';
    $edit_useremail='';
    $edit_userfullname='';
    $edit_useraccesslevel='';
  //Try to get User detail from the DB
    $edituserresults = $userModel->GetUserDetailById($edit_userid);
    //If found then assign the variables
    if(count($edituserresults) > 0)
    {
        $edit_userame = $edituserresults[0]['username'];
        $edit_useractive = $edituserresults[0]['active'];
        $edit_useremail = $edituserresults[0]['email'];
        $edit_userfullname = $edituserresults[0]['fullname'];
        $edit_useraccesslevel = $edituserresults[0]['accesslevel'];
    }
    //Get all Orgs
    $orgModel = new OrgModel();
    $orglistresults  = $orgModel->GetAllOrgs();
?>
<main id="main">
    <div class="container">
    <a name="messageanchor"></a>
    <?php
     if(isset($_SESSION['error'])&&($_SESSION['error']!='')){
        echo '<div class="row justify-content-center py-2">';
        echo '<div class="col">';
        echo '<p class="bg-danger text-white p-2 text-center fs-5">';
        echo $_SESSION['error'];
        echo '</p>';
        echo '</div>';
        echo '</div>';
        $_SESSION['error'] ='';//Clear the session variable so that it is not picked up again
    }
    if(isset($_GET['success'])&&($_GET['success']!='')){
        echo '<div class="row justify-content-center py-2">';
        echo '<div class="col">';
        echo '<p class="text-white bg-success p-2 text-center fs-5">';
        echo $_GET['success'];
        echo '</p>';
        echo '</div>';
        echo '</div>';
    }
    ?>

     <!-- ***************************************************** -->
        <!-- ***************** ADD / EDIT User ********************* -->
        <!-- ***************************************************** -->
        <form action="/Controllers/UserController.php" id="editform" method="post">
        <fieldset class="border rounded-2 py-2">
        <legend class="float-none w-auto px-0 py-3" >Add/Edit User</legend>
        <div class="row justify-content-start py-0">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Id</span>
                    <input type="text" class="form-control-sm" disabled name="id" value="<?php echo $edit_userid;?>"/>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Username</span>
                    <input type="text" class="form-control-sm" required name="username" value="<?php echo $edit_userame;?>"/>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Fullname</span>
                    <input type="text" class="form-control-sm" required name="fullname" value="<?php echo $edit_userfullname;?>"/>
                                            
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Active</span>
                    <select required name="active" class="form-select-sm">
                        <option value="Y"<?=$edit_useractive == 'Y' ? 'selected="selected"' : '';?>>Y</option>
                        <option value="N"<?=$edit_useractive == 'N' ? 'selected="selected"' : '';?>>N</option>
                    </select>
                                            
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Email</span>
                    <input type="email" class="form-control-sm" required name="email" value="<?php echo $edit_useremail;?>"/>
                                            
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">AccessLevel</span>
                    <select required name="accesslevel" class="form-select-sm">
                        <option value="OrgUser"<?=$edit_useraccesslevel == 'Y' ? 'selected="selected"' : '';?>>OrgUser</option>
                        <option value="OrgAdmin"<?=$edit_useraccesslevel == 'N' ? 'selected="selected"' : '';?>>OrgAdmin</option>
                        <option value="SuperUser"<?=$edit_useraccesslevel == 'N' ? 'selected="selected"' : '';?>>SuperUser</option>
                    </select>
                                            
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-4">
                    <span class="input-group-text">Organisation</span>
                    <select required name="orgname" class="form-select-sm">
                        <?php 
                        foreach($orglistresults as $org)
                        {
                                echo '<option value="'.$org['org_name'].'">'. $org['org_name']. '</option>';
                           
                        } 
                        
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="input-group mb-2">
                    <input class="btn btn-secondary" type="submit" value="Add/Update"/>
                    <input type="hidden" name="action" value="UpsertUser"/>
                    <input type="hidden" name="id" value="<?php echo $edit_userid;?>"/>
                </div>
            </div>
        </div>
        </fieldset>
        </form>
         <!-- ***************************************************** -->
        <!-- ***************** Query Data ********************* -->
        <!-- ***************************************************** -->
        <form action="/Views/UserList" id="queryform" method="post">
        <fieldset class="border rounded-2 py-1">
            <div class="row justify-content-center py-0">
                <div class="col-12">
                    <div class="input-group mb-2">
                        <span class="input-group-text">Search Organisation:</span>
                        <select id="searchOrgName" name="SearchOrgName" class="form-select-sm">
                            <option value="">-- All --</option>
                            <?php 
                            foreach($orglistresults as $org)
                            {
                                if($org['org_name'] == $orgName)
                                {
                                    echo '<option value="'.$org['org_name'].'" selected="selected">'. $org['org_name']. '</option>';
                                }
                                else
                                {
                                    echo '<option value="'.$org['org_name'].'">'. $org['org_name']. '</option>';

                                }
                                
                            } 
                           
                            
                            ?>
                        </select>
                       <input type="hidden" name="edit_userid" id="edit_userid" />
                    </div>
                </div>
            </div>
        </fieldset>
        </form>

     <!-- ***************************************************** -->
        <!-- ***************** User List  ********************* -->
        <!-- ***************************************************** -->
       
        <div class="row justify-content-center py-0">
            <div class="col-12">
                <div class="table-responsive" id="UserDiv">
                    <table class="table table-hover table-striped" id="ResultTable">
                        <thead class="table-info">
                            <tr>
                                <th>Id</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Active</th>
                                <th>Organisation</th>
                                <th>AccessLevel</th>
                                <th>LastLogin</th>
                                <th>Updated</th>
                                <th>Updated By</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php 
                            foreach($userlist as $usr)
                            {
                                echo '<tr>';
                                echo '<td>'.$usr['id'].'</td>';
                                //echo '<td>'.$usr['username'].'&nbsp;<a href="/Views/UserList?edit_userid='.$usr['id'].'"><i class="bi bi-pencil-square"></i></a>'.'</td>';
                                echo '<td>'.$usr['username'].'&nbsp;<a href="#" attr-userid="'.$usr['id'].'" class="edituserclass"><i class="edituser bi bi-pencil-square"></i></a>'.'</td>';
                                echo '<td>'.$usr['email'].'</td>';
                                echo '<td>'.$usr['active'].'</td>';
                                echo '<td>'.$usr['org_name'].'</td>';
                                echo '<td>'.$usr['accesslevel'].'</td>';
                                //Convert the dates into local time
                                $updated = '';
                                if($usr['updated'] != null)
                                {
                                    $updatedTS = new DateTime($usr['updated']);
                                    $updatedTS = $updatedTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                                    $updated = $updatedTS->format('Y-m-d H:i:s'); // Change to Sydney
                                }

                                $lastlogin = '';
                                if($usr['last_login'] != null)
                                {
                                    $lastloginTS = new DateTime($usr['last_login']);
                                    $lastloginTS = $lastloginTS->setTimeZone(new DateTimeZone('Australia/Sydney'));
                                    $lastlogin = $lastloginTS->format('Y-m-d H:i:s'); // Change to Sydney
                                }
                                echo '<td>'.$lastlogin.'</td>';
                                echo '<td>'.$updated.'</td>';
                                echo '<td>'.$usr['updated_by'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" attr-username="'.$usr['username'].'" attr-orgname="'.$usr['org_name'].'" class="deleteuserclass"><i class="bi bi-trash"></i></a></td>';
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                        
                    </table>
                    
                </div>
            </div>
        </div>
   
        <!-- Set hidden field to indicate which nav bar LI is to be marked as active -->
        <input type="hidden" id="activemenuid" value="navbar-administration"/> 
        <div style="visibility: hidden;">
            <form action="/Controllers/UserController.php" id="deleteform" method="post">
                <input name="delete_username" id="delete_username" value=""/>
                <input name="delete_orgname" id="delete_orgname" value=""/>
                <input name="action" value="DeleteUserOrg"/>
            </form>                            

        </div>
    </div>
</main>
<?php 
include_once('carsalesfooter.php');

?>

    <script>
        $(document).ready(function () {
            //Initialise the Data Table as responsive
            new DataTable('#ResultTable', {
                responsive: true,
                pageLength: 30
            });

            $('#UserDiv').on('click','.deleteuserclass',function() {
            var username = $(this).attr('attr-username');
            var orgname = $(this).attr('attr-orgname');
            var sConfirm = confirm('Do you really want to delete the User :' + username + ' from the Organisation:' + orgname + '?');
            if(sConfirm == false)return;
            $('#delete_username').val(username);
            $('#delete_orgname').val(orgname);
            $('#deleteform').submit();

            });

            $('#UserDiv').on('click','.edituserclass',function() {
            var edituserid = $(this).attr('attr-userid');
            $('#edit_userid').val(edituserid);
            $('#queryform').submit();

            });
            //Disable submit buttons on form submissions
            $("#deleteform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });

            $("#editform").submit(function (e) {
                $(":submit").attr('disabled','disabled');
            });
            //Filter Type dropdown list change
            $('#searchOrgName').change(function () {
                $('#queryform').submit();
            });
            
        });
    </script>

