$(document).ready(function () {
    //Get the SalesNo value from the URL parameter and update the URLs for the navbar links at the top
    var salesNo = $('#sales_no').val();
    
    var href = $('#navbar-info').attr('href');
    $('#navbar-info').attr('href',href + salesNo);//Add salesNo to the end of the Href
    var href = $('#navbar-log').attr('href');
    $('#navbar-log').attr('href',href + salesNo);//Add salesNo to the end of the Href
    var href = $('#navbar-note').attr('href');
    $('#navbar-note').attr('href',href + salesNo);//Add salesNo to the end of the Href
    var href = $('#navbar-file').attr('href');
    $('#navbar-file').attr('href',href + salesNo);//Add salesNo to the end of the Href
    $('#delete_sales_no').val(salesNo);//Populate the sales no for the Delete From called by the Delete Link on the NavBar
     //Get the active menu Id from the hidden input, set the appropriate navbar as active
    if ( $('#activemenuid').length ) {
        activemenuid = $('#activemenuid').val();
    }
    if ( $('#'+activemenuid).length ) {
        $('#'+activemenuid).addClass("active");
    }

    $('#delete-menu').click(function(){

    });
   
});

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}