﻿/// <reference path="../jquery-1.10.0.min.js" />
$(document).ready(function () {


    //Action SearchButton Function
    $('#SendMessageButton').on("click", function () {
        //Get the inputs
        var name = $('#name').val();
        var email = $('#email').val();
        var phone = $('#phone').val();
        var message = $('#message').val();

        if ((name == '') || (email == '') || (phone == '') || (message == '')) {
            alert('Please provide all inputs');
            return;
        }


        //Send an AJAX request to call the controller to do the lookup
        var sURL = "/Home/ContactEmail";
        $.ajax({
            url: sURL,
            type: "POST",
            data: {
                name: name,
                email: email,
                phone: phone,
                message: message
            },
            beforeSend: function () {
                $.blockUI({ message: '<h1><img src="/images/busy.gif" /> Please wait...</h1>' });
            }
        })
        .done(function (partialViewResult) {
            $('#EmailResult').empty();
            $('#EmailResult').append(partialViewResult);
            $.unblockUI();
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
                $('#EmailResult').empty();
                $('#EmailResult').append(errorThrown);
                $.unblockUI();
            });

    });

});

