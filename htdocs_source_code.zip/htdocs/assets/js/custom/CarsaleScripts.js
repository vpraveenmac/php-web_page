﻿$(document).ready(function () {

   

    $('#ResultTable tbody tr td').not('.idcell').on('click', function () {

           var id = $(this).closest('tr').find('td.idcell').text();
           var url = "/Carsales/EditCarsale/" + id;
           var windowname = "Sale_" + id;
           window.open(url, windowname); 

    });


       //Subscribe to the Select/Deselect Checkbox for the All CheckBox
       $('#SelectAllCB').on("change", function () {
           var selected = false;
           if ($(this).is(":checked")) {
               selected = true;
           }
           //Go through all the check boxes and set them to the same state as that of the All Checkbox
           $("input:checkbox[name=SelectCB]").each(function () {
               if (selected) {
                   $(this).attr('checked', 'checked');
               }
               else {
                   $(this).removeAttr('checked');
               }
           });

       });


       //Action Selected Button Function
       $('#ActionSelectedButton').on("click", function () {

           //Get the list of all selected entries
           var selectedEntries = '';
           var count = 0;
           $("input:checkbox[name=SelectCB]:checked").each(function () {
               // add $(this).val() to your array
               selectedEntries += $(this).val() + "|";
               count++;
           });
           if (count <= 0) {
               alert('No entries selected');
               return false;
           }

           //Get the selected action
           var action = $('#SelectedItemAction').val();
           if (action == '') {
               alert('No action selected');
               return false;
           }
           var sConfirm = confirm(action + ' selected entries?');
           if (sConfirm == false) {
               return;
           }

           //Send an AJAX request to call the controller to do the lookup
           var sURL = "/Job/ActionSelected";
           $.ajax({
               url: sURL,
               type: "POST",
               data: {
                   SelectedEntries: selectedEntries,
                   Action: action
               },
               beforeSend: function () {
                   $.blockUI({ message: '<h1><img src="/images/busy.gif" /> Please wait...</h1>' });
               }
           })
               .done(function (partialViewResult) {
                   $('#ActionMessage').html(partialViewResult);
                   $.unblockUI();
               })
               .fail(function (jqXHR, textStatus, errorThrown) {
                   $('#ActionMessage').html(errorThrown);
                   $.unblockUI();
               });


       });
});
