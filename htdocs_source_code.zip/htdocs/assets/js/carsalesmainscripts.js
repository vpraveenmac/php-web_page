$(document).ready(function () {
    //Get the active menu Id from the URL parameter, set the appropriate navbar as active
    var activemenuid = getUrlVars()["menuid"];
   /* if(getUrlVars()["menuid"].length){
        activemenuid = getUrlVars()["menuid"];
    } */
    
    //Next we will check from the page. It takes precedence
    if ( $('#activemenuid').length ) {
        activemenuid = $('#activemenuid').val();
    }

    if ( $('#'+activemenuid).length ) {
 
        $('#'+activemenuid).addClass("active");
    }
    else{
        $('#navbar-home').addClass("active");
    }



   
});

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}